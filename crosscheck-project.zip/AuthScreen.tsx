import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { Eye, EyeOff, Mail, Lock, User, Building2, MapPin, CheckCircle2, AlertCircle, Loader2, ArrowLeft } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuthStore } from '../store'

const GoogleIcon = () => (
  <svg width="18" height="18" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
    <path d="M43.611 20.083H42V20H24v8h11.303C33.654 32.657 29.332 36 24 36c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z" fill="#FFC107" />
    <path d="M6.306 14.691l6.571 4.819C14.655 15.108 19.001 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 16.318 4 9.656 8.337 6.306 14.691z" fill="#FF3D00" />
    <path d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0124 36c-5.311 0-9.821-3.317-11.387-7.909l-6.527 5.025C9.505 39.556 16.227 44 24 44z" fill="#4CAF50" />
    <path d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 01-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z" fill="#1976D2" />
  </svg>
)

function PasswordInput({ id, placeholder, register, error }: { id: string; placeholder: string; register: any; error?: any }) {
  const [show, setShow] = useState(false)
  return (
    <div>
      <div className="relative">
        <input id={id} type={show ? 'text' : 'password'} placeholder={placeholder}
          {...register} className="input-field pr-10" />
        <button type="button" tabIndex={-1}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
          onClick={() => setShow(s => !s)}>
          {show ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>
      {error && <p className="text-red-400 text-xs mt-1 flex items-center gap-1"><AlertCircle size={12} />{error.message}</p>}
    </div>
  )
}

// ─── Employee Panel ───────────────────────────────────────────────────────────
function EmployeePanel() {
  const navigate = useNavigate()
  const { setUser } = useAuthStore()
  const [mode, setMode] = useState<'signup' | 'signin'>('signup')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [termsChecked, setTermsChecked] = useState(false)

  const { register, handleSubmit, formState: { errors }, watch, reset } = useForm<any>({ mode: 'onBlur' })
  const password = watch('password')

  const switchMode = (m: 'signup' | 'signin') => {
    setMode(m); setError(''); setSuccess(''); reset()
  }

  // ── Sign Up ──────────────────────────────────────────────────────────────────
  const onSignUp = async (data: any) => {
    setError(''); setSuccess(''); setLoading(true)
    try {
      const { error: err } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: { data: { name: data.name, role: 'employee' } },
      })
      if (err) throw err
      setSuccess('Account created! Check your email to confirm, then Sign In below.')
      reset()
    } catch (e: any) {
      console.error('Sign up error:', e)
      setError(e.message || 'Account creation failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // ── Sign In ──────────────────────────────────────────────────────────────────
  const onSignIn = async (data: any) => {
    setError(''); setLoading(true)
    console.log('🔐 Starting sign in with email:', data.email)

    const timeoutId = setTimeout(() => {
      console.error('❌ Login timeout - Supabase request took too long')
      setLoading(false)
      setError('Login took too long. Please check your connection and try again.')
    }, 15000)

    try {
      console.log('📡 Calling supabase.auth.signInWithPassword...')
      const { data: authData, error: err } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      })
      console.log('✅ Auth response received:', { hasUser: !!authData?.user, hasError: !!err })

      if (err) {
        clearTimeout(timeoutId)
        console.error('❌ Auth error:', err)
        // Check for common email confirmation error
        if (err.message?.includes('Email not confirmed')) {
          setError('Please confirm your email before signing in. Check your inbox for a confirmation link.')
        } else {
          setError(err.message || 'Sign in failed. Please check your email and password.')
        }
        setLoading(false)
        return
      }

      if (!authData.user) {
        clearTimeout(timeoutId)
        console.error('❌ No user in auth response')
        setError('Sign in failed: no user returned')
        setLoading(false)
        return
      }

      console.log('👤 User authenticated:', authData.user.id)
      // Explicitly fetch profile and navigate — don't rely solely on AuthListener timing
      const { data: profiles, error: profileErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authData.user.id)
        .limit(1)

      clearTimeout(timeoutId)
      console.log('📋 Profile fetch result:', { count: profiles?.length || 0, hasError: !!profileErr })

      if (profileErr) {
        // Profile query failed
        console.error('❌ Profile fetch error:', profileErr)
        setError('Failed to load profile. Please try again.')
        setLoading(false)
        return
      }

      const profile = profiles && profiles.length > 0 ? profiles[0] : null

      if (profile) {
        setUser(profile as any)
        setLoading(false)
        console.log('✅ Profile found, navigating...')
        navigate(profile.role === 'employer' ? '/employer' : '/home')
      } else {
        // Profile not yet created by trigger — navigate to tier anyway
        setUser({
          id: authData.user.id,
          email: authData.user.email!,
          name: authData.user.user_metadata?.name || authData.user.email!.split('@')[0],
          role: authData.user.user_metadata?.role || 'employee',
          tier: 'free',
          verified: false,
          photo_url: null,
          created_at: new Date().toISOString()
        } as any)
        
        setLoading(false)
        console.log('⚠️ No profile found, navigating to tier selection...')
        navigate('/onboarding/tier')
      }
    } catch (e: any) {
      clearTimeout(timeoutId)
      console.error('❌ Sign in error:', e)
      setError(e.message || 'An unexpected error occurred. Please try again.')
      setLoading(false)
    }
  }

  // ── Google OAuth ─────────────────────────────────────────────────────────────
  // redirectTo must match the exact URL authorized in Supabase.
  // Using just the origin is safer as it's typically the default authorized URL.
  const onGoogleSignIn = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin },
    })
  }

  const isSignUp = mode === 'signup'

  return (
    <div className="space-y-4">
      {/* Mode toggle */}
      <div className="glass rounded-xl p-1 flex mb-2">
        {(['signup', 'signin'] as const).map(m => (
          <button key={m} type="button" onClick={() => switchMode(m)}
            className="flex-1 py-2 rounded-lg text-xs font-semibold transition-all"
            style={mode === m ? { background: 'rgba(99,102,241,0.25)', color: '#a5b4fc' } : { color: '#64748b' }}>
            {m === 'signup' ? 'Create Account' : 'Sign In'}
          </button>
        ))}
      </div>

      <button type="button" id="google-oauth-employee" className="btn-outline w-full gap-3" onClick={onGoogleSignIn}>
        <GoogleIcon /> Continue with Google
      </button>
      <div className="flex items-center gap-3 my-1">
        <div className="flex-1 h-px bg-surface-600" />
        <span className="text-slate-600 text-xs uppercase tracking-wider">or</span>
        <div className="flex-1 h-px bg-surface-600" />
      </div>

      <form onSubmit={handleSubmit(isSignUp ? onSignUp : onSignIn)} className="space-y-4">
        {isSignUp && (
          <div>
            <label className="input-label">Full Name</label>
            <div className="relative">
              <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input type="text" placeholder="Jane Doe" {...register('name', { required: 'Required' })} className="input-field pl-9" />
            </div>
            {errors.name && <p className="text-red-400 text-xs mt-1 flex items-center gap-1"><AlertCircle size={12} />{String(errors.name.message)}</p>}
          </div>
        )}

        <div>
          <label className="input-label">Email Address</label>
          <div className="relative">
            <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input type="email" placeholder="jane@email.com" {...register('email', { required: 'Required' })} className="input-field pl-9" />
          </div>
          {errors.email && <p className="text-red-400 text-xs mt-1 flex items-center gap-1"><AlertCircle size={12} />{String(errors.email.message)}</p>}
        </div>

        <div>
          <label className="input-label">Password</label>
          <PasswordInput id="emp-pwd" placeholder="Min 8 characters"
            register={register('password', { required: 'Required', minLength: { value: 8, message: 'Min 8 characters' } })}
            error={errors.password} />
        </div>

        {isSignUp && (
          <>
            <div>
              <label className="input-label">Confirm Password</label>
              <PasswordInput id="emp-cpwd" placeholder="Repeat password"
                register={register('confirmPassword', {
                  required: 'Required',
                  validate: (v: string) => v === password || 'Passwords do not match',
                })} error={errors.confirmPassword} />
            </div>
            <label className="flex items-start gap-3 cursor-pointer">
              <input type="checkbox" id="emp-terms" checked={termsChecked} onChange={e => setTermsChecked(e.target.checked)}
                className="mt-0.5 accent-brand-500 w-4 h-4 rounded" />
              <span className="text-slate-400 text-sm">
                I agree to the <a href="/terms.html" target="_blank" className="text-brand-400 hover:underline">Terms &amp; Conditions</a>
              </span>
            </label>
          </>
        )}

        {error && (
          <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">
            <AlertCircle size={14} /> {error}
          </div>
        )}
        {success && (
          <div className="flex items-center gap-2 text-accent-400 text-sm bg-accent-500/10 border border-accent-500/20 rounded-xl px-4 py-3">
            <CheckCircle2 size={14} /> {success}
          </div>
        )}

        <button type="submit" id="emp-submit" className="btn-primary w-full mt-2 gap-2"
          disabled={loading || (isSignUp && !termsChecked)}>
          {loading
            ? <><Loader2 size={16} className="animate-spin" /> Processing…</>
            : isSignUp ? 'Create Employee Account' : 'Sign In'}
        </button>
      </form>
    </div>
  )
}

// ─── Employer Panel ───────────────────────────────────────────────────────────
function EmployerPanel() {
  const navigate = useNavigate()
  const { setUser } = useAuthStore()
  const [mode, setMode] = useState<'signup' | 'signin'>('signup')
  const [termsChecked, setTermsChecked] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const { register, handleSubmit, formState: { errors }, watch, reset } = useForm<any>({ mode: 'onBlur' })
  const password = watch('password')

  const switchMode = (m: 'signup' | 'signin') => {
    setMode(m); setError(''); setSuccess(''); reset()
  }

  // ── Sign Up ──────────────────────────────────────────────────────────────────
  const onSignUp = async (data: any) => {
    setError(''); setSuccess(''); setLoading(true)
    try {
      const { data: authData, error: err } = await supabase.auth.signUp({
        email: data.companyEmail,
        password: data.password,
        options: { data: { name: data.employerName, role: 'employer' } },
      })
      if (err) throw err

      const userId = authData.user?.id
      if (!userId) throw new Error('User creation failed')

      await new Promise(r => setTimeout(r, 1000))

      await supabase.from('employer_profiles').upsert({
        id: userId,
        company_name: data.companyName,
        designation: data.designation,
        company_address: data.companyAddress,
      })

      await supabase.from('profiles').update({ tier: 'pro' }).eq('id', userId)

      setSuccess('Account created! Check your email to confirm, then Sign In below.')
      reset()
    } catch (e: any) {
      console.error('Employer sign up error:', e)
      setError(e.message || 'Account creation failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // ── Sign In ──────────────────────────────────────────────────────────────────
  const onSignIn = async (data: any) => {
    setError(''); setLoading(true)
    console.log('🔐 Starting employer sign in with email:', data.signinEmail)

    const timeoutId = setTimeout(() => {
      console.error('❌ Login timeout - Supabase request took too long')
      setLoading(false)
      setError('Login took too long. Please check your connection and try again.')
    }, 15000)

    try {
      console.log('📡 Calling supabase.auth.signInWithPassword...')
      const { data: authData, error: err } = await supabase.auth.signInWithPassword({
        email: data.signinEmail,
        password: data.signinPassword,
      })
      console.log('✅ Auth response received:', { hasUser: !!authData?.user, hasError: !!err })

      if (err) {
        clearTimeout(timeoutId)
        console.error('❌ Auth error:', err)
        // Check for common email confirmation error
        if (err.message?.includes('Email not confirmed')) {
          setError('Please confirm your email before signing in. Check your inbox for a confirmation link.')
        } else {
          setError(err.message || 'Sign in failed. Please check your email and password.')
        }
        setLoading(false)
        return
      }

      if (!authData.user) {
        clearTimeout(timeoutId)
        console.error('❌ No user in auth response')
        setError('Sign in failed: no user returned')
        setLoading(false)
        return
      }

      console.log('👤 User authenticated:', authData.user.id)
      const { data: profiles, error: profileErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authData.user.id)
        .limit(1)

      clearTimeout(timeoutId)
      console.log('📋 Profile fetch result:', { count: profiles?.length || 0, hasError: !!profileErr })

      if (profileErr) {
        // Profile query failed
        console.error('❌ Profile fetch error:', profileErr)
        setError('Failed to load profile. Please try again.')
        setLoading(false)
        return
      }

      const profile = profiles && profiles.length > 0 ? profiles[0] : null

      if (profile) {
        setUser(profile as any)
        setLoading(false)
        console.log('✅ Profile found, navigating to employer...')
        navigate('/employer')
      } else {
        // Profile not yet created — navigate to tier
        setUser({
          id: authData.user.id,
          email: authData.user.email!,
          name: authData.user.user_metadata?.name || authData.user.email!.split('@')[0],
          role: authData.user.user_metadata?.role || 'employer',
          tier: 'free',
          verified: false,
          photo_url: null,
          created_at: new Date().toISOString()
        } as any)
        
        setLoading(false)
        console.log('⚠️ No profile found, navigating to tier selection...')
        navigate('/onboarding/tier')
      }
    } catch (e: any) {
      clearTimeout(timeoutId)
      console.error('❌ Employer sign in error:', e)
      setError(e.message || 'An unexpected error occurred. Please try again.')
      setLoading(false)
    }
  }

  const isSignUp = mode === 'signup'

  return (
    <div className="space-y-4">
      {/* Mode toggle */}
      <div className="glass rounded-xl p-1 flex mb-2">
        {(['signup', 'signin'] as const).map(m => (
          <button key={m} type="button" onClick={() => switchMode(m)}
            className="flex-1 py-2 rounded-lg text-xs font-semibold transition-all"
            style={mode === m
              ? { background: 'rgba(5,150,105,0.25)', color: '#6ee7b7' }
              : { color: '#64748b' }}>
            {m === 'signup' ? 'Create Account' : 'Sign In'}
          </button>
        ))}
      </div>

      {isSignUp ? (
        <form onSubmit={handleSubmit(onSignUp)} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="input-label">Company Name</label>
              <div className="relative">
                <Building2 size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input type="text" placeholder="Acme Corp" {...register('companyName', { required: true })} className="input-field pl-9" />
              </div>
            </div>
            <div>
              <label className="input-label">Your Full Name</label>
              <div className="relative">
                <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input type="text" placeholder="John Smith" {...register('employerName', { required: true })} className="input-field pl-9" />
              </div>
            </div>
          </div>

          <div>
            <label className="input-label">Designation / Role</label>
            <input type="text" placeholder="HR Manager, CTO, Recruiter…" {...register('designation', { required: true })} className="input-field" />
          </div>

          <div>
            <label className="input-label">Company Address</label>
            <div className="relative">
              <MapPin size={15} className="absolute left-3 top-3 text-slate-500" />
              <textarea rows={2} placeholder="Full address" {...register('companyAddress', { required: true })} className="input-field pl-9 resize-none" />
            </div>
          </div>

          <div>
            <label className="input-label">Company Email</label>
            <div className="relative">
              <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input type="email" placeholder="hr@company.com" {...register('companyEmail', { required: true })} className="input-field pl-9" />
            </div>
          </div>

          <div>
            <label className="input-label">Password</label>
            <PasswordInput id="er-pwd" placeholder="8+ characters"
              register={register('password', { required: true, minLength: 8 })} error={errors.password} />
          </div>
          <div>
            <label className="input-label">Confirm Password</label>
            <PasswordInput id="er-cpwd" placeholder="Repeat password"
              register={register('confirmPassword', {
                required: true,
                validate: (v: string) => v === password || 'Passwords do not match',
              })} error={errors.confirmPassword} />
          </div>

          <label className="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" checked={termsChecked} onChange={e => setTermsChecked(e.target.checked)}
              className="mt-0.5 accent-brand-500 w-4 h-4 rounded" />
            <span className="text-slate-400 text-sm">
              I agree to the <a href="/terms.html" target="_blank" className="text-brand-400 hover:underline">Terms &amp; Conditions</a>
            </span>
          </label>

          {error && (
            <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">
              <AlertCircle size={14} /> {error}
            </div>
          )}
          {success && (
            <div className="flex items-center gap-2 text-accent-400 text-sm bg-accent-500/10 border border-accent-500/20 rounded-xl px-4 py-3">
              <CheckCircle2 size={14} /> {success}
            </div>
          )}

          <button type="submit" id="er-submit" className="btn-primary w-full mt-2 gap-2"
            disabled={!termsChecked || loading}
            style={{ background: loading ? undefined : 'linear-gradient(135deg,#059669,#047857)' }}>
            {loading
              ? <><Loader2 size={16} className="animate-spin" /> Creating Account…</>
              : <><Lock size={16} /> Submit to Pay</>}
          </button>
        </form>
      ) : (
        /* ── Employer Sign In ─────────────────────────────────────────────── */
        <form onSubmit={handleSubmit(onSignIn)} className="space-y-4">
          <div>
            <label className="input-label">Company Email</label>
            <div className="relative">
              <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input type="email" placeholder="hr@company.com"
                {...register('signinEmail', { required: 'Required' })}
                className="input-field pl-9" />
            </div>
            {errors.signinEmail && <p className="text-red-400 text-xs mt-1 flex items-center gap-1"><AlertCircle size={12} />{String(errors.signinEmail.message)}</p>}
          </div>

          <div>
            <label className="input-label">Password</label>
            <PasswordInput id="er-signin-pwd" placeholder="Your password"
              register={register('signinPassword', { required: 'Required' })}
              error={errors.signinPassword} />
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">
              <AlertCircle size={14} /> {error}
            </div>
          )}

          <button type="submit" id="er-signin-submit" className="btn-primary w-full gap-2"
            disabled={loading}
            style={{ background: loading ? undefined : 'linear-gradient(135deg,#059669,#047857)' }}>
            {loading
              ? <><Loader2 size={16} className="animate-spin" /> Signing In…</>
              : <><Lock size={16} /> Sign In to Employer Portal</>}
          </button>
        </form>
      )}
    </div>
  )
}

// ─── Main Auth Screen ─────────────────────────────────────────────────────────
export default function AuthScreen() {
  const navigate = useNavigate()
  const [panel, setPanel] = useState<'employee' | 'employer'>('employee')

  return (
    <div className="min-h-screen bg-surface-900 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="glow-orb w-96 h-96 bg-brand-600 opacity-15 top-[-10%] right-[-5%] animate-glow-pulse" />
      <div className="glow-orb w-72 h-72 bg-accent-500 opacity-10 bottom-[-5%] left-[-5%] animate-glow-pulse" style={{ animationDelay: '1s' }} />
      <div className="absolute inset-0 bg-grid-pattern pointer-events-none" />

      <button onClick={() => navigate('/')} 
        className="absolute top-6 left-6 z-20 flex items-center gap-2 text-slate-400 hover:text-white transition-colors bg-surface-800/50 hover:bg-surface-700/50 px-4 py-2 rounded-xl backdrop-blur-md border border-surface-700">
        <ArrowLeft size={18} />
        <span className="text-sm font-medium">Back to Home</span>
      </button>

      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-lg mt-12 md:mt-0">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 mb-4">
            <img src="/logo.png" alt="CrossCheck Logo" className="w-full h-full object-contain" />
          </div>
          <h2 className="font-display font-bold text-3xl text-white">Join CrossCheck</h2>
          <p className="text-slate-500 mt-1 text-sm">AI-powered career intelligence platform</p>
        </div>

        <div className="glass rounded-2xl p-1 flex mb-6">
          {(['employee', 'employer'] as const).map(role => (
            <button key={role} id={`tab-${role}`} type="button" onClick={() => setPanel(role)}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 capitalize"
              style={panel === role
                ? {
                  background: role === 'employee'
                    ? 'linear-gradient(135deg,#6366f1,#4f46e5)'
                    : 'linear-gradient(135deg,#059669,#047857)',
                  color: '#fff',
                  boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
                }
                : { color: '#64748b' }}>
              {role === 'employee' ? '👤 For Employee' : '🏢 For Employer'}
            </button>
          ))}
        </div>

        <div className="glass rounded-2xl p-6 md:p-8">
          <AnimatePresence mode="wait">
            <motion.div key={panel}
              initial={{ opacity: 0, x: panel === 'employee' ? -20 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: panel === 'employee' ? 20 : -20 }}
              transition={{ duration: 0.25 }}>
              {panel === 'employee' ? <EmployeePanel /> : <EmployerPanel />}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  )
}
