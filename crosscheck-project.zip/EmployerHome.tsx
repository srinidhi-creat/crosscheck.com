import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, RefreshCw, ChevronDown, ChevronUp, SlidersHorizontal, Star, MapPin, Briefcase, MessageSquare, X, Check } from 'lucide-react'
import { MOCK_CANDIDATES } from '../lib/mockData'

function ScorePill({ value, color }: { value: number; color: string }) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold"
      style={{ background: `${color}18`, color, border: `1px solid ${color}40` }}>
      {value}
    </span>
  )
}

function FilterSidebar({ filters, setFilters, onApply, onReset }: any) {
  const [open, setOpen] = useState<string[]>(['score', 'experience'])

  const toggle = (key: string) =>
    setOpen(prev => prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key])

  const AccordionSection = ({ id, label, children }: any) => (
    <div className="border-b border-surface-700">
      <button onClick={() => toggle(id)} className="w-full flex items-center justify-between px-5 py-3.5 text-sm font-medium text-slate-300 hover:text-white transition-colors">
        {label}
        {open.includes(id) ? <ChevronUp size={15} className="text-slate-500" /> : <ChevronDown size={15} className="text-slate-500" />}
      </button>
      <AnimatePresence>
        {open.includes(id) && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }}
            className="px-5 pb-4">
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )

  const RangeInput = ({ label, filterKey, min, max, unit }: any) => (
    <div>
      <div className="flex justify-between text-xs text-slate-500 mb-1">
        <span>{label}</span>
        <span>{filters[filterKey]}+ {unit}</span>
      </div>
      <input type="range" min={min} max={max} value={filters[filterKey]}
        onChange={e => setFilters((f: any) => ({ ...f, [filterKey]: +e.target.value }))}
        className="w-full accent-brand-500 cursor-pointer" />
    </div>
  )

  const expOptions = ['Fresher', 'Junior (1–3)', 'Mid (3–6)', 'Senior (6+)']
  const eduOptions = ['Any', "Bachelor's", "Master's", 'PhD', 'Diploma']
  const availOptions = ['Immediate', '15 days', '30 days', '60+ days']

  return (
    <aside className="w-full md:w-64 shrink-0 glass rounded-2xl overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-surface-700">
        <div className="flex items-center gap-2">
          <SlidersHorizontal size={16} className="text-brand-400" />
          <span className="font-semibold text-white text-sm">Filters</span>
        </div>
        <button onClick={onReset} className="text-slate-500 text-xs hover:text-brand-400 transition-colors">Reset All</button>
      </div>

      <AccordionSection id="score" label="Points Scored">
        <RangeInput label="Minimum Score" filterKey="minScore" min={0} max={100} unit="" />
        <RangeInput label="Potential Score" filterKey="minPotential" min={0} max={100} unit="" />
      </AccordionSection>

      <AccordionSection id="experience" label="Experience Level">
        <div className="space-y-2">
          {expOptions.map(opt => {
            const sel = filters.experience.includes(opt)
            return (
              <button key={opt} onClick={() => setFilters((f: any) => ({ ...f, experience: sel ? f.experience.filter((e: string) => e !== opt) : [...f.experience, opt] }))}
                className="w-full flex items-center gap-2.5 text-sm py-1.5 transition-colors"
                style={{ color: sel ? '#a5b4fc' : '#64748b' }}>
                <span className="w-4 h-4 rounded border flex items-center justify-center"
                  style={{ borderColor: sel ? '#6366f1' : '#374151', background: sel ? '#6366f1' : 'transparent' }}>
                  {sel && <Check size={10} className="text-white" />}
                </span>
                {opt}
              </button>
            )
          })}
        </div>
      </AccordionSection>

      <AccordionSection id="salary" label="Salary Expectation">
        <RangeInput label="Min Budget (LPA)" filterKey="minSalary" min={0} max={50} unit="LPA" />
        <RangeInput label="Max Budget (LPA)" filterKey="maxSalary" min={0} max={100} unit="LPA" />
      </AccordionSection>

      <AccordionSection id="comm" label="Communication Score">
        <RangeInput label="Min Comm Score" filterKey="minComm" min={0} max={100} unit="" />
      </AccordionSection>

      <AccordionSection id="education" label="Education">
        <div className="space-y-2">
          {eduOptions.map(opt => {
            const sel = filters.education === opt
            return (
              <button key={opt} onClick={() => setFilters((f: any) => ({ ...f, education: opt }))}
                className="w-full flex items-center gap-2.5 text-sm py-1 transition-colors"
                style={{ color: sel ? '#a5b4fc' : '#64748b' }}>
                <span className="w-4 h-4 rounded-full border flex items-center justify-center"
                  style={{ borderColor: sel ? '#6366f1' : '#374151' }}>
                  {sel && <span className="w-2 h-2 rounded-full bg-brand-500" />}
                </span>
                {opt}
              </button>
            )
          })}
        </div>
      </AccordionSection>

      <AccordionSection id="avail" label="Availability">
        <div className="space-y-2">
          {availOptions.map(opt => {
            const sel = filters.availability === opt
            return (
              <button key={opt} onClick={() => setFilters((f: any) => ({ ...f, availability: opt }))}
                className="w-full flex items-center gap-2.5 text-sm py-1 transition-colors"
                style={{ color: sel ? '#a5b4fc' : '#64748b' }}>
                <span className="w-4 h-4 rounded-full border flex items-center justify-center"
                  style={{ borderColor: sel ? '#6366f1' : '#374151' }}>
                  {sel && <span className="w-2 h-2 rounded-full bg-brand-500" />}
                </span>
                {opt}
              </button>
            )
          })}
        </div>
      </AccordionSection>

      <div className="p-4">
        <button onClick={onApply} className="btn-primary w-full text-sm py-2.5">Apply Filters</button>
      </div>
    </aside>
  )
}

function CandidateCard({ candidate, onShortlist }: any) {
  const [expanded, setExpanded] = useState(false)

  return (
    <motion.div layout className="glass rounded-2xl overflow-hidden">
      {/* Card header */}
      <div className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap">
              <h3 className="font-semibold text-white">{candidate.name}</h3>
              {candidate.shortlisted && <span className="badge badge-green gap-1"><Star size={10} />Shortlisted</span>}
            </div>
            <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-500">
              <span className="flex items-center gap-1"><Briefcase size={11} />{candidate.exp}</span>
              <span className="flex items-center gap-1"><MapPin size={11} />{candidate.location}</span>
              <span className="flex items-center gap-1"><MessageSquare size={11} />Comm: {candidate.commScore}</span>
            </div>
            <div className="flex flex-wrap gap-1.5 mt-2.5">
              {candidate.skills.map((s: string) => <span key={s} className="badge badge-brand text-[10px]">{s}</span>)}
            </div>
          </div>
          {/* Score badges */}
          <div className="flex flex-col items-end gap-1.5 ml-4 shrink-0">
            <ScorePill value={candidate.score} color="#6366f1" />
            <span className="text-slate-600 text-[10px]">score</span>
            <ScorePill value={candidate.potential} color="#10b981" />
            <span className="text-slate-600 text-[10px]">potential</span>
          </div>
        </div>

        {/* Comm score bar */}
        <div className="mt-4">
          <div className="flex justify-between text-xs text-slate-500 mb-1">
            <span>Communication</span><span>{candidate.commScore}/100</span>
          </div>
          <div className="h-1.5 bg-surface-600 rounded-full overflow-hidden">
            <motion.div className="h-full rounded-full"
              style={{ background: 'linear-gradient(90deg,#6366f1,#10b981)' }}
              initial={{ width: 0 }} animate={{ width: `${candidate.commScore}%` }}
              transition={{ duration: 0.8, ease: 'easeOut' }} />
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 mt-4">
          <button onClick={() => setExpanded(e => !e)}
            className="flex-1 py-2 rounded-xl text-xs font-semibold transition-all"
            style={{ background: 'rgba(99,102,241,0.12)', color: '#a5b4fc', border: '1px solid rgba(99,102,241,0.25)' }}>
            {expanded ? 'Hide Details' : 'View More'}
          </button>
          <button onClick={() => onShortlist(candidate.id)}
            className="flex-1 py-2 rounded-xl text-xs font-semibold transition-all"
            style={candidate.shortlisted
              ? { background: 'rgba(16,185,129,0.12)', color: '#34d399', border: '1px solid rgba(16,185,129,0.25)' }
              : { background: 'rgba(255,255,255,0.04)', color: '#64748b', border: '1px solid rgba(255,255,255,0.08)' }}>
            {candidate.shortlisted ? '★ Shortlisted' : '☆ Shortlist'}
          </button>
        </div>
      </div>

      {/* Expanded details drawer */}
      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}
            className="border-t border-surface-700 p-5 space-y-3">
            {[
              { label: 'Education', value: candidate.edu },
              { label: 'Salary Expectation', value: candidate.salary },
              { label: 'Availability', value: candidate.availability },
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between text-sm">
                <span className="text-slate-500">{label}</span>
                <span className="text-white font-medium">{value}</span>
              </div>
            ))}
            <div className="grid grid-cols-3 gap-3 pt-2">
              {[
                { l: 'Obtained', v: candidate.score, c: '#6366f1' },
                { l: 'Potential', v: candidate.potential, c: '#10b981' },
                { l: 'Comm', v: candidate.commScore, c: '#f59e0b' },
              ].map(({ l, v, c }) => (
                <div key={l} className="text-center p-2 rounded-xl" style={{ background: `${c}12`, border: `1px solid ${c}30` }}>
                  <p className="font-bold text-lg" style={{ color: c }}>{v}</p>
                  <p className="text-slate-500 text-xs">{l}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

const DEFAULT_FILTERS = { minScore: 0, minPotential: 0, minComm: 0, minSalary: 0, maxSalary: 100, experience: [] as string[], education: 'Any', availability: '' }

export default function EmployerHome() {
  const [filters, setFilters] = useState(DEFAULT_FILTERS)
  const [candidates, setCandidates] = useState(MOCK_CANDIDATES)
  const [search, setSearch] = useState('')
  const [activeTab, setActiveTab] = useState<'all' | 'shortlisted'>('all')

  const displayed = candidates.filter(c => {
    if (activeTab === 'shortlisted' && !c.shortlisted) return false
    if (c.score < filters.minScore) return false
    if (c.commScore < filters.minComm) return false
    if (search && !c.skills.some(s => s.toLowerCase().includes(search.toLowerCase())) && !c.name.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const toggleShortlist = (id: number) =>
    setCandidates(prev => prev.map(c => c.id === id ? { ...c, shortlisted: !c.shortlisted } : c))

  return (
    <div className="min-h-screen bg-surface-900">
      {/* Top bar */}
      <header className="sticky top-0 z-40 px-6 py-4 flex items-center justify-between"
        style={{ background: 'rgba(10,10,15,0.95)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(99,102,241,0.12)' }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#059669,#047857)' }}>
            <span className="font-display font-black text-white text-sm">CC</span>
          </div>
          <div>
            <span className="font-display font-bold text-white">CrossCheck</span>
            <span className="text-slate-600 text-xs ml-2">Employer Portal</span>
          </div>
        </div>
        <span className="badge badge-green">Employer Active</span>
      </header>

      <div className="flex gap-6 p-6 max-w-7xl mx-auto">
        {/* Filter sidebar */}
        <FilterSidebar filters={filters} setFilters={setFilters}
          onApply={() => {}} onReset={() => setFilters(DEFAULT_FILTERS)} />

        {/* Main content */}
        <div className="flex-1 space-y-5">
          {/* Search + tabs */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input type="text" placeholder="Search by skill or keyword..." value={search}
                onChange={e => setSearch(e.target.value)} className="input-field pl-9" />
            </div>
            <button className="btn-outline flex items-center gap-2 whitespace-nowrap">
              <RefreshCw size={15} /> Refresh
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 glass rounded-xl p-1 w-fit">
            {(['all', 'shortlisted'] as const).map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className="px-5 py-2 rounded-lg text-sm font-semibold capitalize transition-all"
                style={activeTab === tab ? { background: 'linear-gradient(135deg,#059669,#047857)', color: '#fff' } : { color: '#64748b' }}>
                {tab === 'shortlisted' ? `★ ${tab}` : tab} ({tab === 'all' ? candidates.length : candidates.filter(c => c.shortlisted).length})
              </button>
            ))}
          </div>

          {/* Candidate list */}
          <div className="space-y-4">
            {displayed.length === 0 ? (
              <div className="glass rounded-2xl p-10 text-center">
                <X size={32} className="text-slate-600 mx-auto mb-3" />
                <p className="text-slate-500">No candidates match your filters.</p>
              </div>
            ) : displayed.map(c => (
              <CandidateCard key={c.id} candidate={c} onShortlist={toggleShortlist} />
            ))}
          </div>

          {/* Pagination hint */}
          <p className="text-slate-600 text-xs text-center pb-6">
            Showing {displayed.length} of {candidates.length} candidates · Page 1 of 1
          </p>
        </div>
      </div>
    </div>
  )
}
