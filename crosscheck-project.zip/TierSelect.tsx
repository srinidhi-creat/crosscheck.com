import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { Check, Zap, Star, ArrowRight, Lock } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuthStore } from '../store'

const FREE_FEATURES = [
  'Text-based CV scoring',
  'Job Description comparison & score display',
  'AI text suggestions for CV improvement',
  '1 free communication test trial (MCQ only)',
  'Basic dashboard',
]

const PRO_FEATURES = [
  'Everything in Free',
  'LinkedIn profile PDF upload analysis',
  'GitHub profile integration',
  'Company recommendation engine',
  'Full communication test (MCQ + Voice)',
  'Personalized skill betterment suggestions',
]

export default function TierSelect() {
  const navigate = useNavigate()
  const { user, setUser } = useAuthStore()
  const [selected, setSelected] = useState<'free' | 'pro' | null>(null)

  const handleProUpgrade = async () => {
    if (!user?.id) return
    try {
      const { data } = await supabase
        .from('profiles')
        .update({ tier: 'pro' })
        .eq('id', user.id)
        .select('*')
        .single()
      if (data) setUser(data as any)
      navigate('/onboarding/questions')
    } catch (e: any) {
      console.error('Tier upgrade failed:', e.message)
    }
  }

  return (
    <div className="min-h-screen bg-surface-900 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="glow-orb w-96 h-96 bg-brand-600 opacity-10 top-[-10%] left-1/2 -translate-x-1/2 animate-glow-pulse" />
      <div className="absolute inset-0 bg-grid-pattern pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-3xl"
      >
        <div className="text-center mb-10">
          <span className="badge badge-brand mb-3">Choose Your Plan</span>
          <h1 className="font-display font-bold text-4xl text-white mt-2">Unlock Your Career Potential</h1>
          <p className="text-slate-500 mt-2">Start free or go Pro for full AI-powered analysis</p>
        </div>


        <div className="grid md:grid-cols-2 gap-6">
          {/* Free Tier */}
          <motion.div
            whileHover={{ scale: 1.02, y: -4 }}
            onClick={() => setSelected('free')}
            className="cursor-pointer rounded-2xl p-6 transition-all duration-200 relative"
            style={{
              background: selected === 'free' ? 'rgba(99,102,241,0.1)' : 'rgba(255,255,255,0.03)',
              border: selected === 'free' ? '2px solid #6366f1' : '1px solid rgba(99,102,241,0.15)',
              boxShadow: selected === 'free' ? '0 0 30px rgba(99,102,241,0.15)' : 'none',
            }}
          >
            {selected === 'free' && (
              <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-brand-500 flex items-center justify-center">
                <Check size={14} className="text-white" />
              </div>
            )}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-surface-600 flex items-center justify-center">
                <Zap size={20} className="text-brand-400" />
              </div>
              <div>
                <h2 className="font-display font-bold text-xl text-white">Free Tier</h2>
                <p className="text-slate-500 text-sm">No credit card required</p>
              </div>
            </div>
            <div className="mb-6">
              <span className="font-display font-black text-4xl text-white">₹0</span>
              <span className="text-slate-500 text-sm ml-1">forever</span>
            </div>
            <ul className="space-y-3 mb-6">
              {FREE_FEATURES.map(f => (
                <li key={f} className="flex items-start gap-2.5 text-sm text-slate-400">
                  <Check size={15} className="text-accent-400 mt-0.5 shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <button
              id="free-tier-btn"
              onClick={(e) => { e.stopPropagation(); navigate('/onboarding/questions') }}
              className="btn-outline w-full"
            >
              Continue Free <ArrowRight size={16} />
            </button>
          </motion.div>

          {/* Pro Tier */}
          <motion.div
            whileHover={{ scale: 1.02, y: -4 }}
            onClick={() => setSelected('pro')}
            className="cursor-pointer rounded-2xl p-6 transition-all duration-200 relative"
            style={{
              background: selected === 'pro'
                ? 'rgba(99,102,241,0.12)'
                : 'linear-gradient(160deg, rgba(99,102,241,0.08), rgba(16,185,129,0.05))',
              border: selected === 'pro' ? '2px solid #6366f1' : '2px solid rgba(99,102,241,0.3)',
              boxShadow: '0 0 40px rgba(99,102,241,0.1)',
            }}
          >
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold text-white"
              style={{ background: 'linear-gradient(90deg, #6366f1, #818cf8)' }}>
              ✦ MOST POPULAR
            </div>
            {selected === 'pro' && (
              <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-brand-500 flex items-center justify-center">
                <Check size={14} className="text-white" />
              </div>
            )}
            <div className="flex items-center gap-3 mb-4 mt-2">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #6366f1, #4338ca)' }}>
                <Star size={20} className="text-white" />
              </div>
              <div>
                <h2 className="font-display font-bold text-xl text-white">Pro Tier</h2>
                <p className="text-slate-500 text-sm">Full AI suite unlocked</p>
              </div>
            </div>
            <div className="mb-6">
              <span className="font-display font-black text-4xl text-white">₹999</span>
              <span className="text-slate-500 text-sm ml-1">/ one-time</span>
            </div>
            <ul className="space-y-3 mb-6">
              {PRO_FEATURES.map(f => (
                <li key={f} className="flex items-start gap-2.5 text-sm text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-brand-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Check size={10} className="text-brand-300" />
                  </div>
                  {f}
                </li>
              ))}
            </ul>
            <button
              id="pro-tier-btn"
              onClick={(e) => { e.stopPropagation(); handleProUpgrade() }}
              className="btn-primary w-full gap-2"
            >
              <Lock size={16} /> Upgrade to Pro
            </button>
          </motion.div>
        </div>

        <p className="text-center text-slate-600 text-xs mt-6">
          Choose the plan that works best for you
        </p>
      </motion.div>
    </div>
  )
}
