import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { supabase } from '../lib/supabase'
import type { Profile } from '../lib/supabase'

export type UserRole = 'employee' | 'employer' | 'admin'
export type UserTier = 'free' | 'pro'

interface AuthStore {
  user: Profile | null
  isAuthenticated: boolean
  setUser: (user: Profile) => void
  loadSession: () => Promise<void>
  logout: () => Promise<void>
  clearSession: () => void
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,

      setUser: (user) => set({ user, isAuthenticated: true }),

      loadSession: async () => {
        const { data: { session } } = await supabase.auth.getSession()
        if (!session?.user) return

        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single()

        if (profile) {
          set({ user: profile as Profile, isAuthenticated: true })
        }
      },

      logout: async () => {
        try {
          await supabase.auth.signOut()
        } catch (e) {
          console.error("Logout error", e)
        } finally {
          set({ user: null, isAuthenticated: false })
        }
      },

      clearSession: () => {
        set({ user: null, isAuthenticated: false })
      },
    }),
    {
      name: 'crosscheck-auth',
      // Only persist non-sensitive fields; Supabase manages token internally
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
)

// ── UI Store ──────────────────────────────────────────────────────────────────
interface UIStore {
  theme: 'dark' | 'light'
  toggleTheme: () => void
}

export const useUIStore = create<UIStore>()(
  persist(
    (set, get) => ({
      theme: 'dark',
      toggleTheme: () => {
        const next = get().theme === 'dark' ? 'light' : 'dark'
        set({ theme: next })
        document.documentElement.classList.toggle('light', next === 'light')
      },
    }),
    { name: 'crosscheck-ui' }
  )
)
