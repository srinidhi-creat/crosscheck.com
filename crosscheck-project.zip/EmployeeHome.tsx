import { motion } from 'framer-motion'
import { useNavigate, useLocation } from 'react-router-dom'
import { Home, FileText, MessageSquare, LayoutDashboard, Upload, Briefcase, ChevronRight, Star, Zap, TrendingUp } from 'lucide-react'

const NAV_ITEMS = [
  { label: 'Home', icon: Home, path: '/home' },
  { label: 'CV Analysis', icon: FileText, path: '/cv-analysis' },
  { label: 'Comm Test', icon: MessageSquare, path: '/comm-test' },
  { label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
]

const PROMO_CARDS = [
  {
    icon: Star,
    title: 'Upgrade to Pro',
    desc: 'Unlock GitHub integration, voice test & company recommendations',
    gradient: 'linear-gradient(135deg, #6366f1, #4338ca)',
    cta: 'Get Pro →',
  },
  {
    icon: TrendingUp,
    title: 'AI Score is Live',
    desc: 'Our resume scoring model v2 is now more accurate than ever',
    gradient: 'linear-gradient(135deg, #059669, #047857)',
    cta: 'Try Now →',
  },
  {
    icon: Zap,
    title: 'New: Voice Analysis',
    desc: 'Measure your verbal confidence, fluency & professional vocabulary',
    gradient: 'linear-gradient(135deg, #d97706, #b45309)',
    cta: 'Learn More →',
  },
]

export function BottomNav() {
  const location = useLocation()
  const navigate = useNavigate()
  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 md:hidden"
      style={{ background: 'rgba(10,10,15,0.95)', backdropFilter: 'blur(20px)', borderTop: '1px solid rgba(99,102,241,0.15)' }}>
      <div className="flex items-center justify-around px-2 py-2">
        {NAV_ITEMS.map(({ label, icon: Icon, path }) => {
          const active = location.pathname === path
          return (
            <button key={path} onClick={() => navigate(path)}
              className={`nav-tab ${active ? 'active' : ''}`}>
              <Icon size={20} />
              <span>{label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}

export function SideNav() {
  const location = useLocation()
  const navigate = useNavigate()
  return (
    <aside className="hidden md:flex flex-col w-60 shrink-0 min-h-screen sticky top-0"
      style={{ background: 'rgba(18,18,26,0.95)', borderRight: '1px solid rgba(99,102,241,0.12)' }}>
      {/* Logo */}
      <div className="p-6 border-b border-surface-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 flex items-center justify-center">
            <img src="/logo.png" alt="CrossCheck Logo" className="w-full h-full object-contain" />
          </div>
          <span className="font-display font-bold text-white text-lg">CrossCheck</span>
        </div>
      </div>

      {/* Nav links */}
      <nav className="flex-1 p-4 space-y-1">
        {NAV_ITEMS.map(({ label, icon: Icon, path }) => {
          const active = location.pathname === path
          return (
            <button key={path} onClick={() => navigate(path)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150"
              style={{
                background: active ? 'rgba(99,102,241,0.15)' : 'transparent',
                color: active ? '#a5b4fc' : '#64748b',
                border: active ? '1px solid rgba(99,102,241,0.25)' : '1px solid transparent',
              }}>
              <Icon size={18} />
              {label}
            </button>
          )
        })}
      </nav>

      {/* Bottom: version */}
      <div className="p-4 border-t border-surface-700">
        <p className="text-slate-700 text-xs text-center">CrossCheck v1.0 · 2026</p>
      </div>
    </aside>
  )
}

export default function EmployeeHome() {
  const navigate = useNavigate()

  return (
    <div className="flex min-h-screen bg-surface-900">
      <SideNav />
      <main className="flex-1 pb-20 md:pb-0 overflow-y-auto">

        {/* Hero Banner */}
        <section className="relative overflow-hidden px-6 py-16 md:px-12"
          style={{ background: 'linear-gradient(160deg, #0d0d1a, #12122a)' }}>
          <div className="glow-orb w-80 h-80 bg-brand-600 opacity-15 top-[-30%] right-[-10%] animate-glow-pulse" />
          <div className="absolute inset-0 bg-grid-pattern pointer-events-none opacity-50" />
          <motion.div
            initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
            className="relative z-10 max-w-xl">
            <span className="badge badge-brand mb-3">AI Career Platform</span>
            <h1 className="font-display font-black text-4xl md:text-5xl text-white leading-tight mt-2">
              Intelligent <br />
              <span style={{ background: 'linear-gradient(90deg,#818cf8,#34d399)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Resume Analysis
              </span>
            </h1>
            <p className="text-slate-400 mt-4 text-lg leading-relaxed max-w-md">
              Upload your CV and job description. Get scored, compare against real JDs, and discover your next opportunity.
            </p>
            <div className="flex flex-wrap gap-3 mt-6">
              <button onClick={() => navigate('/cv-analysis')}
                id="hero-cv-btn" className="btn-primary gap-2">
                <Upload size={18} /> Upload Your CV
              </button>
              <button onClick={() => navigate('/comm-test')}
                id="hero-comm-btn" className="btn-outline gap-2">
                <MessageSquare size={18} /> Take Communication Test
              </button>
            </div>
          </motion.div>
        </section>

        {/* Features grid */}
        <section className="px-6 md:px-12 py-10">
          <h2 className="font-display font-bold text-2xl text-white mb-6">What CrossCheck Does</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { icon: FileText, title: 'CV Scoring', desc: '3-dimensional score: Obtained, Potential & Negative Grade', color: '#6366f1' },
              { icon: MessageSquare, title: 'Comm Test', desc: 'Grammar, verbal fluency & professional short-form assessment', color: '#10b981' },
              { icon: Briefcase, title: 'Company Match', desc: 'AI recommends companies that match your exact skill profile', color: '#f59e0b' },
            ].map(({ icon: Icon, title, desc, color }) => (
              <motion.div key={title} whileHover={{ y: -4 }}
                className="glass rounded-2xl p-5 cursor-pointer"
                style={{ borderColor: `${color}22` }}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                  style={{ background: `${color}20` }}>
                  <Icon size={20} style={{ color }} />
                </div>
                <h3 className="font-semibold text-white mb-1">{title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Promo carousel */}
        <section className="px-6 md:px-12 py-4">
          <h2 className="font-display font-bold text-2xl text-white mb-6">What's New</h2>
          <div className="flex gap-4 overflow-x-auto pb-3 snap-x snap-mandatory scrollbar-thin">
            {PROMO_CARDS.map(({ icon: Icon, title, desc, gradient, cta }) => (
              <motion.div key={title} whileHover={{ scale: 1.02 }}
                className="snap-start shrink-0 w-72 rounded-2xl p-5 relative overflow-hidden cursor-pointer"
                style={{ background: gradient }}>
                <div className="absolute inset-0 bg-black/20" />
                <div className="relative z-10">
                  <Icon size={24} className="text-white/80 mb-3" />
                  <h3 className="font-display font-bold text-lg text-white">{title}</h3>
                  <p className="text-white/70 text-sm mt-1 leading-relaxed">{desc}</p>
                  <button className="mt-4 text-white font-semibold text-sm hover:underline flex items-center gap-1">
                    {cta} <ChevronRight size={14} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* About / Dev credits */}
        <section className="px-6 md:px-12 py-10">
          <div className="glass rounded-2xl p-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 mb-4">
              <img src="/logo.png" alt="CrossCheck Logo" className="w-full h-full object-contain" />
            </div>
            <h2 className="font-display font-bold text-2xl text-white mb-2">About CrossCheck</h2>
            <p className="text-slate-400 max-w-lg mx-auto leading-relaxed">
              CrossCheck bridges the communication gap between employers and job-seekers through
              intelligent, data-driven resume analysis — powered by <span className="text-brand-400">100% in-house AI models</span> trained
              on real-world career data.
            </p>
            <div className="flex items-center justify-center gap-2 mt-6">
              <span className="text-slate-600 text-sm">Built by</span>
              {['Sri', 'Rishi', 'Arkesh', 'Likith'].map(name => (
                <span key={name} className="badge badge-brand">{name}</span>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="px-6 md:px-12 py-8 border-t border-surface-700 text-center">
          <p className="text-slate-600 text-xs">
            © 2026 CrossCheck.com · <a href="/terms" className="hover:text-brand-400 transition-colors">Terms</a> ·
            <a href="#" className="hover:text-brand-400 transition-colors ml-2">Privacy</a> ·
            <a href="#" className="hover:text-brand-400 transition-colors ml-2">Contact</a>
          </p>
        </footer>
      </main>
      <BottomNav />
    </div>
  )
}
