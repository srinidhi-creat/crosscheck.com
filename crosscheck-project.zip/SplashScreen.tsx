import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'

export default function SplashScreen() {
  const navigate = useNavigate()
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    // Animate progress 0→100 over 2.5s
    const start = Date.now()
    const duration = 2500
    const frame = () => {
      const elapsed = Date.now() - start
      const pct = Math.min((elapsed / duration) * 100, 100)
      setProgress(pct)
      if (pct < 100) {
        requestAnimationFrame(frame)
      } else {
        setTimeout(() => navigate('/brand'), 300)
      }
    }
    requestAnimationFrame(frame)
  }, [navigate])

  return (
    <div className="relative min-h-screen bg-surface-900 flex flex-col items-center justify-center overflow-hidden">

      {/* Grid overlay */}
      <div className="absolute inset-0 bg-grid-pattern opacity-100 pointer-events-none" />

      {/* Glow orbs */}
      <div className="glow-orb w-96 h-96 bg-brand-600 opacity-20 top-[-10%] left-[-10%] animate-glow-pulse" />
      <div className="glow-orb w-80 h-80 bg-accent-500 opacity-15 bottom-[-5%] right-[-5%] animate-glow-pulse" style={{ animationDelay: '1.5s' }} />
      <div className="glow-orb w-64 h-64 bg-brand-400 opacity-10 top-[40%] right-[20%] animate-glow-pulse" style={{ animationDelay: '0.8s' }} />

      {/* Logo mark */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="relative z-10 flex flex-col items-center gap-8"
      >
        {/* CC Monogram */}
        <div className="relative">
          <div className="w-24 h-24 flex items-center justify-center">
            <img src="/logo.png" alt="CrossCheck Logo" className="w-full h-full object-contain drop-shadow-[0_0_30px_rgba(99,102,241,0.4)]" />
          </div>
          {/* Ring */}
          <div className="absolute inset-[-8px] rounded-[2rem] border border-brand-500/30 animate-spin-slow" />
        </div>

        {/* Brand name */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="text-center"
        >
          <h1 className="font-display font-bold text-2xl text-white tracking-wide">
            Cross<span className="text-brand-400">Check</span>
          </h1>
          <p className="text-slate-500 text-xs mt-1 tracking-widest uppercase">AI Career Platform</p>
        </motion.div>

        {/* Progress bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="w-64"
        >
          <div className="h-1 rounded-full bg-surface-600 overflow-hidden">
            <div
              className="h-full rounded-full transition-none"
              style={{
                width: `${progress}%`,
                background: 'linear-gradient(90deg, #6366f1, #34d399)',
                boxShadow: '0 0 10px rgba(99,102,241,0.6)',
                transition: 'width 0.05s linear',
              }}
            />
          </div>
          <p className="text-center text-slate-600 text-xs mt-2 tabular-nums">
            {Math.round(progress)}%
          </p>
        </motion.div>
      </motion.div>
    </div>
  )
}
