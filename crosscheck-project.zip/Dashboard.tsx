import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Mail, Moon, Sun, CreditCard, Shield, Info, ChevronRight, Camera, LogOut, Loader2 } from 'lucide-react'
import { SideNav, BottomNav } from './EmployeeHome'
import { useUIStore, useAuthStore } from '../store'
import { supabase } from '../lib/supabase'
import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
  const navigate = useNavigate()
  const { theme, toggleTheme } = useUIStore()
  const { user, setUser, logout } = useAuthStore()
  const [activeSection, setActiveSection] = useState<string | null>(null)
  const [editingName, setEditingName] = useState(false)
  const [name, setName] = useState(user?.name || '')
  const [savingName, setSavingName] = useState(false)
  const [stats, setStats] = useState({ cvCount: 0, bestScore: 0, commScore: 0 })
  const [uploadingPhoto, setUploadingPhoto] = useState(false)

  const onImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user?.id) return
    
    setUploadingPhoto(true)
    const reader = new FileReader()
    // Read and compress image down trivially for base64 limits
    reader.onloadend = async () => {
      const base64String = reader.result as string
      // In production, we would use Supabase storage. For now, base64 data URLs work fine natively.
      const { data, error } = await supabase
        .from('profiles')
        .update({ photo_url: base64String })
        .eq('id', user.id)
        .select('*')
        .single()
        
      if (data) setUser(data as any)
      setUploadingPhoto(false)
    }
    reader.readAsDataURL(file)
  }

  // Fetch real stats from Supabase
  useEffect(() => {
    if (!user?.id) return
    const fetchStats = async () => {
      const [{ data: cvs }, { data: comms }] = await Promise.all([
        supabase.from('cv_analyses').select('result_json').eq('user_id', user.id),
        supabase.from('comm_results').select('score').eq('user_id', user.id).order('score', { ascending: false }).limit(1),
      ])
      const bestScore = cvs?.reduce((max: number, row: any) => {
        const s = row.result_json?.obtained ?? 0
        return s > max ? s : max
      }, 0) ?? 0
      setStats({
        cvCount: cvs?.length ?? 0,
        bestScore,
        commScore: comms?.[0]?.score ?? 0,
      })
    }
    fetchStats()
  }, [user?.id])

  const saveName = async () => {
    if (!user?.id) return
    setSavingName(true)
    const { data } = await supabase
      .from('profiles')
      .update({ name })
      .eq('id', user.id)
      .select('*')
      .single()
    if (data) setUser(data as any)
    setSavingName(false)
    setEditingName(false)
  }

  const handleLogout = async () => {
    await logout()
    navigate('/auth')
  }

  const settingsItems = [
    { id: 'theme', icon: theme === 'dark' ? Moon : Sun, label: 'Appearance', value: theme === 'dark' ? 'Dark Mode' : 'Light Mode', action: toggleTheme },
    { id: 'payment', icon: CreditCard, label: 'Payment Details', value: `${user?.tier === 'pro' ? 'Pro — ₹999 paid' : 'Free Tier'}`, action: () => setActiveSection('payment') },
    { id: 'privacy', icon: Shield, label: 'Account & Privacy', value: 'Manage data & consent', action: () => setActiveSection('privacy') },
    { id: 'about', icon: Info, label: 'About CrossCheck', value: 'v1.0 · Sri, Rishi, Arkesh, Likith', action: () => setActiveSection('about') },
  ]

  return (
    <div className="flex min-h-screen bg-surface-900">
      <SideNav />
      <main className="flex-1 pb-20 md:pb-0 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-6 py-10 space-y-6">

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="badge badge-brand mb-3">Account</span>
            <h1 className="font-display font-bold text-3xl text-white mt-1">Dashboard</h1>
          </motion.div>

          {/* Profile card */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="glass rounded-2xl p-6">
            <div className="flex items-center gap-5">
              <div className="relative">
                <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-2xl font-bold text-white overflow-hidden"
                  style={{ background: 'linear-gradient(135deg, #6366f1, #4338ca)' }}>
                  {user?.photo_url ? (
                    <img src={user.photo_url} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    (name || user?.email || 'U').charAt(0).toUpperCase()
                  )}
                </div>
                <label className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full flex items-center justify-center cursor-pointer transition-all hover:scale-105"
                  style={{ background: '#1a1a26', border: '2px solid rgba(99,102,241,0.4)' }}>
                  <input type="file" accept="image/*" className="hidden" disabled={uploadingPhoto} onChange={onImageSelect} />
                  {uploadingPhoto ? <Loader2 size={12} className="text-brand-400 animate-spin" /> : <Camera size={12} className="text-brand-400" />}
                </label>
              </div>

              <div className="flex-1">
                {editingName ? (
                  <div className="flex items-center gap-2">
                    <input autoFocus value={name} onChange={e => setName(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') setEditingName(false) }}
                      className="input-field text-lg font-bold py-1 px-2 w-full max-w-xs" />
                    <button onClick={saveName} disabled={savingName}
                      className="btn-primary py-1 px-3 text-xs">
                      {savingName ? <Loader2 size={12} className="animate-spin" /> : 'Save'}
                    </button>
                  </div>
                ) : (
                  <button onClick={() => setEditingName(true)}
                    className="font-display font-bold text-xl text-white hover:text-brand-300 transition-colors text-left">
                    {name || user?.name || 'Your Name'} <span className="text-slate-600 text-sm font-normal">✏️</span>
                  </button>
                )}
                <div className="flex items-center gap-2 mt-1">
                  <Mail size={13} className="text-slate-500" />
                  <span className="text-slate-400 text-sm">{user?.email}</span>
                </div>
                <div className="flex gap-2 mt-2">
                  <span className="badge badge-brand">Employee</span>
                  {user?.tier === 'pro'
                    ? <span className="badge badge-green">Pro</span>
                    : <span className="badge" style={{ background: 'rgba(100,116,139,0.2)', color: '#94a3b8', border: '1px solid rgba(100,116,139,0.3)' }}>Free</span>}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Stats row */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
            className="grid grid-cols-3 gap-3">
            {[
              { label: 'CV Analyses', value: String(stats.cvCount) },
              { label: 'Best Score', value: stats.bestScore ? String(stats.bestScore) : '—' },
              { label: 'Comm Score', value: stats.commScore ? String(stats.commScore) : '—' },
            ].map(({ label, value }) => (
              <div key={label} className="glass rounded-xl p-4 text-center">
                <p className="font-display font-black text-2xl text-white">{value}</p>
                <p className="text-slate-500 text-xs mt-1">{label}</p>
              </div>
            ))}
          </motion.div>

          {/* Settings list */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
            className="glass rounded-2xl overflow-hidden">
            <p className="px-5 pt-4 pb-2 text-slate-500 text-xs uppercase tracking-wider font-medium">Settings</p>
            {settingsItems.map(({ id, icon: Icon, label, value, action }) => (
              <button key={id} onClick={action}
                className="w-full flex items-center gap-4 px-5 py-4 hover:bg-white/5 transition-all text-left border-t border-surface-700 first-of-type:border-0">
                <div className="w-9 h-9 rounded-xl bg-surface-600 flex items-center justify-center shrink-0">
                  <Icon size={16} className="text-brand-400" />
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm font-medium">{label}</p>
                  <p className="text-slate-500 text-xs">{value}</p>
                </div>
                <ChevronRight size={16} className="text-slate-600" />
              </button>
            ))}
          </motion.div>

          {/* About panel */}
          {activeSection === 'about' && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="glass rounded-2xl p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-3 flex items-center justify-center">
                <img src="/logo.png" alt="CrossCheck Logo" className="w-full h-full object-contain" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">CrossCheck.com</h3>
              <p className="text-slate-500 text-sm mt-1">Version 1.0 · April 2026</p>
              <p className="text-slate-400 text-sm mt-3">AI-powered resume &amp; job market analysis platform</p>
              <div className="flex justify-center gap-2 mt-4">
                {['Sri', 'Rishi', 'Arkesh', 'Likith'].map(n => <span key={n} className="badge badge-brand">{n}</span>)}
              </div>
            </motion.div>
          )}

          {/* Logout */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
            <button onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-red-400 text-sm font-medium transition-all hover:bg-red-500/10"
              style={{ border: '1px solid rgba(239,68,68,0.2)' }}>
              <LogOut size={16} /> Sign Out
            </button>
          </motion.div>
        </div>
      </main>
      <BottomNav />
    </div>
  )
}
