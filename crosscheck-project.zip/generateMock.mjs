import fs from 'fs'
import path from 'path'

const datasetPath = path.join(process.cwd(), 'kaggle datasets/archive (2)/job_dataset.json')

let rawData = ''
try {
  rawData = fs.readFileSync(datasetPath, 'utf8')
} catch (err) {
  console.error("Failed to read dataset:", err)
  process.exit(1)
}

// Some datasets have weird trailing commas or concatenated arrays, so simple parse:
let jobs = []
try {
  jobs = JSON.parse(rawData)
} catch (err) {
  console.log("JSON parse error, attempting to sanitize...")
  try {
     const text = rawData.replace(/\]\s*\[/g, ',')
     jobs = JSON.parse(text)
  } catch (e2) {
     console.error("Sanitization failed", e2)
     process.exit(1)
  }
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

const locations = ['Bangalore', 'Remote', 'Hyderabad', 'Chennai', 'Pune', 'Mumbai', 'Delhi', 'Gurgaon']
const educations = ["Bachelor's", "Master's", "PhD", "Diploma", "Any"]
const availabilities = ['Immediate', '15 days', '30 days', '60+ days']

const firstNames = ['Aarav', 'Vihaan', 'Aditya', 'Sai', 'Arjun', 'Rohan', 'Kabir', 'Om', 'Ananya', 'Diya', 'Suhana', 'Kavya', 'Neha', 'Priya', 'Swati', 'Meera']
const lastNames = ['Sharma', 'Patel', 'Reddy', 'Singh', 'Gupta', 'Kumar', 'Joshi', 'Nair', 'Das', 'Iyer', 'Menon', 'Rao']

function generateCandidate(id, job) {
  const isMale = Math.random() > 0.5
  const name = `${firstNames[getRandomInt(0, firstNames.length - 1)]} ${lastNames[getRandomInt(0, lastNames.length - 1)]}`
  
  const score = getRandomInt(45, 95)
  const potential = Math.min(100, score + getRandomInt(5, 15))
  const commScore = getRandomInt(50, 95)
  
  const expYears = getRandomInt(0, 10)
  let exp = ''
  if (expYears === 0) exp = 'Fresher'
  else if (expYears <= 3) exp = `Junior (${expYears} yrs)`
  else if (expYears <= 6) exp = `Mid (${expYears} yrs)`
  else exp = `Senior (${expYears} yrs)`

  const baseSkills = job.Keywords || []
  // Randomize some skills
  const skillsCount = getRandomInt(3, 8)
  const skills = baseSkills.sort(() => 0.5 - Math.random()).slice(0, skillsCount)
  // Ensure strings
  const cleanSkills = skills.map((s) => s.trim()).filter((s) => s.length > 0)

  const salary = getRandomInt(3, 40) + ' LPA'
  
  return {
    id,
    name,
    title: job.Title || 'Software Engineer',
    score,
    potential,
    commScore,
    exp,
    skills: cleanSkills.length ? cleanSkills : ['React', 'JavaScript', 'Node.js'],
    location: locations[getRandomInt(0, locations.length - 1)],
    edu: educations[getRandomInt(0, educations.length - 1)],
    salary,
    availability: availabilities[getRandomInt(0, availabilities.length - 1)],
    shortlisted: false
  }
}

const companiesPool = ['Zepto', 'Swiggy', 'Razorpay', 'CRED', 'Flipkart', 'Amazon', 'Google', 'Microsoft', 'Atlassian', 'Uber', 'Ola', 'Paytm', 'Zomato', 'Freshworks', 'ThoughtWorks']

function generateCompany(job) {
  const match = getRandomInt(65, 98)
  const cName = companiesPool[getRandomInt(0, companiesPool.length - 1)]
  const baseSkills = job.Keywords || []
  const skillsCount = getRandomInt(3, 5)
  const cleanSkills = baseSkills.sort(() => 0.5 - Math.random()).slice(0, skillsCount).map((s) => s.trim()).filter((s) => s.length > 0)

  return {
    name: cName,
    match,
    role: job.Title || 'Software Engineer',
    skills: cleanSkills.length ? cleanSkills : ['SQL', 'Python']
  }
}

const SHUFFLED_JOBS = jobs.sort(() => 0.5 - Math.random())

const CANDIDATES = SHUFFLED_JOBS.slice(0, 50).map((job, idx) => generateCandidate(idx + 1, job))
const COMPANIES = SHUFFLED_JOBS.slice(50, 80).map((job) => generateCompany(job))

const output = `// Auto-generated mock data from Kaggle dataset

export const MOCK_CANDIDATES = ${JSON.stringify(CANDIDATES, null, 2)};

export const MOCK_COMPANIES = ${JSON.stringify(COMPANIES, null, 2)};
`

fs.writeFileSync(path.join(process.cwd(), 'src/lib/mockData.ts'), output)
console.log('Successfully generated src/lib/mockData.ts with', CANDIDATES.length, 'candidates and', COMPANIES.length, 'companies.')
