import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Mic, MicOff, Clock, ChevronLeft, ChevronRight, CheckCircle2, Lock, Send, AlertCircle } from 'lucide-react'
import { SideNav, BottomNav } from './EmployeeHome'

const MCQ_QUESTIONS = [
  { id: 1, block: 'Grammar', question: '"He doesn\'t know the answer." — which version is correct?', options: ['He don\'t know the answer.', 'He doesn\'t knows the answer.', 'He doesn\'t know the answer.', 'He not know the answer.'], answer: 2 },
  { id: 2, block: 'Grammar', question: 'Identify the word used correctly:', options: ['Their going to the office.', 'There going to the office.', 'They\'re going to the office.', 'Theyre going to the office.'], answer: 2 },
  { id: 3, block: 'Grammar', question: 'Fill in: "Neither the manager nor the employees ___ happy."', options: ['was', 'were', 'is', 'are being'], answer: 1 },
  { id: 4, block: 'Verbal', question: 'Most professional way to begin a formal email:', options: ['Hey!', 'Hi there,', 'Dear Mr./Ms. [Last Name],', 'Hello buddy,'], answer: 2 },
  { id: 5, block: 'Verbal', question: 'Which tone is appropriate when declining a meeting professionally?', options: ['Sorry, I\'m busy.', 'I appreciate the invite, but have a prior commitment. Could we reschedule?', 'Nope, can\'t make it.', 'I don\'t think that will work.'], answer: 1 },
  { id: 6, block: 'Verbal', question: 'How should you end a professional email requesting feedback?', options: ['Waiting for your reply.', 'Let me know ASAP.', 'I look forward to your thoughts. Thank you for your time.', 'Reply soon.'], answer: 2 },
  { id: 7, block: 'Shortforms', question: 'What does "KPI" stand for?', options: ['Key Performance Indicator', 'Key Process Integration', 'Knowledge Progress Index', 'Key Priority Item'], answer: 0 },
  { id: 8, block: 'Shortforms', question: 'What does "CTC" mean in a job offer?', options: ['Cost to Company', 'Current Total Compensation', 'Contract Terms & Conditions', 'Core Technical Competency'], answer: 0 },
  { id: 9, block: 'Shortforms', question: '"OKR" stands for?', options: ['Online Knowledge Repository', 'Objectives and Key Results', 'Operational KPI Record', 'Output and Key Reporting'], answer: 1 },
  { id: 10, block: 'Shortforms', question: '"P&L" in business refers to?', options: ['Policy & Law', 'Product & Launch', 'Profit & Loss', 'People & Leadership'], answer: 2 },
]

const VOICE_QUESTIONS = [
  'Introduce yourself in 60 seconds — cover your background, key skills, and what you bring to the table.',
  'Describe a challenging project. What was your role and what did you achieve?',
  'How do you handle tight deadlines and competing priorities?',
  'What makes you a strong candidate for this role?',
  'Where do you see yourself professionally in the next 3 years?',
]

function MCQSection({ onComplete }: { onComplete: () => void }) {
  const [current, setCurrent] = useState(0)
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [timeLeft, setTimeLeft] = useState(25 * 60)
  const q = MCQ_QUESTIONS[current]

  useEffect(() => {
    if (timeLeft <= 0) { onComplete(); return }
    const t = setInterval(() => setTimeLeft(s => s - 1), 1000)
    return () => clearInterval(t)
  }, [timeLeft, onComplete])

  const mins = Math.floor(timeLeft / 60).toString().padStart(2, '0')
  const secs = (timeLeft % 60).toString().padStart(2, '0')
  const isWarning = timeLeft < 300
  const blockColors: Record<string, string> = { Grammar: '#6366f1', Verbal: '#10b981', Shortforms: '#f59e0b' }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between glass rounded-2xl px-5 py-3">
        <div className="flex items-center gap-2">
          <Clock size={16} className={isWarning ? 'text-red-400' : 'text-slate-500'} />
          <span className={`font-mono font-bold text-xl ${isWarning ? 'text-red-400' : 'text-white'}`}>{mins}:{secs}</span>
          {isWarning && <span className="badge badge-red text-[10px]">Running low!</span>}
        </div>
        <span className="text-slate-500 text-sm">{Object.keys(answers).length}/{MCQ_QUESTIONS.length} answered</span>
      </div>

      <div className="flex gap-2">
        {['Grammar', 'Verbal', 'Shortforms'].map(b => (
          <div key={b} className="flex-1 text-center py-1.5 rounded-lg text-xs font-semibold"
            style={{ background: q.block === b ? `${blockColors[b]}25` : 'rgba(255,255,255,0.04)', color: q.block === b ? blockColors[b] : '#64748b' }}>
            {b}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={q.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
          className="glass rounded-2xl p-6">
          <p className="text-slate-500 text-xs mb-2">Q{q.id} of {MCQ_QUESTIONS.length}</p>
          <p className="text-white font-medium text-lg leading-relaxed mb-6">{q.question}</p>
          <div className="space-y-2.5">
            {q.options.map((opt, i) => {
              const sel = answers[q.id] === i
              return (
                <button key={i} onClick={() => setAnswers(prev => ({ ...prev, [q.id]: i }))}
                  className="w-full text-left px-4 py-3 rounded-xl text-sm transition-all"
                  style={{ background: sel ? 'rgba(99,102,241,0.18)' : 'rgba(255,255,255,0.04)', border: sel ? '1.5px solid #6366f1' : '1px solid rgba(255,255,255,0.07)', color: sel ? '#c7d2fe' : '#94a3b8' }}>
                  <span className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full border flex items-center justify-center shrink-0 text-xs font-bold"
                      style={{ borderColor: sel ? '#6366f1' : '#374151', color: sel ? '#6366f1' : '#64748b' }}>
                      {String.fromCharCode(65 + i)}
                    </span>
                    {opt}
                  </span>
                </button>
              )
            })}
          </div>
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between">
        <button onClick={() => setCurrent(c => Math.max(0, c - 1))} disabled={current === 0} className="btn-outline disabled:opacity-30 flex items-center gap-2">
          <ChevronLeft size={18} /> Previous
        </button>
        {current < MCQ_QUESTIONS.length - 1
          ? <button onClick={() => setCurrent(c => c + 1)} className="btn-primary flex items-center gap-2">Next <ChevronRight size={18} /></button>
          : <button onClick={onComplete} className="btn-primary flex items-center gap-2"><Send size={16} /> Submit MCQ</button>}
      </div>
    </div>
  )
}

function VoiceSection({ onComplete }: { onComplete: () => void }) {
  const [current, setCurrent] = useState(0)
  const [recording, setRecording] = useState(false)
  const [hasMic, setHasMic] = useState<boolean | null>(null)
  const [transcripts, setTranscripts] = useState<Record<number, string>>({})
  const mediaRef = useRef<MediaRecorder | null>(null)

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(() => setHasMic(true)).catch(() => setHasMic(false))
  }, [])

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    const mr = new MediaRecorder(stream); mediaRef.current = mr; mr.start(); setRecording(true)
  }
  const stopRecording = () => {
    mediaRef.current?.stop(); setRecording(false)
    setTimeout(() => setTranscripts(prev => ({ ...prev, [current]: 'AI transcript will appear here after processing...' })), 1200)
  }

  if (hasMic === false) return (
    <div className="glass rounded-2xl p-8 text-center">
      <AlertCircle size={40} className="text-red-400 mx-auto mb-4" />
      <h3 className="font-semibold text-white text-xl mb-2">Microphone Access Required</h3>
      <p className="text-slate-500">Allow microphone access in your browser settings to take the Voice Test.</p>
    </div>
  )

  return (
    <div className="space-y-6">
      <div className="glass rounded-xl px-5 py-3 flex items-center justify-between">
        <span className="text-slate-400 text-sm">Question {current + 1} of {VOICE_QUESTIONS.length}</span>
        <div className="h-1.5 w-32 bg-surface-600 rounded-full overflow-hidden">
          <div className="h-full rounded-full bg-brand-500" style={{ width: `${((current + 1) / VOICE_QUESTIONS.length) * 100}%` }} />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={current} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
          className="glass rounded-2xl p-8 text-center">
          <p className="text-slate-500 text-xs uppercase tracking-wider mb-4">Voice Question {current + 1}</p>
          <p className="text-white text-xl font-medium leading-relaxed">{VOICE_QUESTIONS[current]}</p>
          <div className="mt-8 flex flex-col items-center gap-4">
            <button onClick={recording ? stopRecording : startRecording}
              className="w-20 h-20 rounded-full flex items-center justify-center transition-all"
              style={{ background: recording ? 'rgba(239,68,68,0.2)' : 'linear-gradient(135deg,#6366f1,#4338ca)', border: recording ? '3px solid #ef4444' : '3px solid transparent', boxShadow: recording ? '0 0 30px rgba(239,68,68,0.4)' : '0 0 30px rgba(99,102,241,0.4)' }}>
              {recording ? <MicOff size={32} className="text-red-400" /> : <Mic size={32} className="text-white" />}
            </button>
            <p className="text-sm text-slate-500">
              {recording ? <span className="text-red-400 flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />Recording… Click to stop</span>
                : transcripts[current] ? 'Recorded ✓' : 'Click to start recording'}
            </p>
            {transcripts[current] && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full text-left p-4 rounded-xl"
                style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.2)' }}>
                <p className="text-xs text-slate-500 mb-1">AI Transcript:</p>
                <p className="text-slate-300 text-sm">{transcripts[current]}</p>
              </motion.div>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between">
        <button onClick={() => setCurrent(c => Math.max(0, c - 1))} disabled={current === 0} className="btn-outline disabled:opacity-30 flex items-center gap-2">
          <ChevronLeft size={18} /> Previous
        </button>
        {current < VOICE_QUESTIONS.length - 1
          ? <button onClick={() => setCurrent(c => c + 1)} className="btn-primary flex items-center gap-2">Next <ChevronRight size={18} /></button>
          : <button onClick={onComplete} className="btn-primary flex items-center gap-2"><CheckCircle2 size={16} /> Complete Test</button>}
      </div>
    </div>
  )
}

function ScoreResults() {
  const scores = [
    { label: 'Grammar Score', score: 74, color: '#6366f1' },
    { label: 'Confidence Score', score: 67, color: '#10b981' },
    { label: 'Professional Vocabulary', score: 82, color: '#f59e0b' },
  ]
  return (
    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="text-center"><CheckCircle2 size={48} className="text-accent-400 mx-auto mb-3" /><h2 className="font-display font-bold text-2xl text-white">Communication Test Complete!</h2></div>
      <div className="glass rounded-2xl p-8 flex flex-wrap justify-around gap-8">
        {scores.map(({ label, score, color }) => {
          const r = 45; const c = 2 * Math.PI * r
          return (
            <div key={label} className="flex flex-col items-center gap-3">
              <div className="relative w-28 h-28">
                <svg width="112" height="112" style={{ transform: 'rotate(-90deg)' }}>
                  <circle cx="56" cy="56" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
                  <motion.circle cx="56" cy="56" r={r} fill="none" stroke={color} strokeWidth="8" strokeLinecap="round"
                    strokeDasharray={c} initial={{ strokeDashoffset: c }} animate={{ strokeDashoffset: c * (1 - score / 100) }}
                    transition={{ duration: 1.2, ease: 'easeOut' }} style={{ filter: `drop-shadow(0 0 5px ${color})` }} />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-display font-black text-2xl text-white">{score}</span>
                </div>
              </div>
              <span className="text-slate-400 text-xs text-center font-medium max-w-[90px]">{label}</span>
            </div>
          )
        })}
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="font-semibold text-white mb-4">Error Summary</h3>
        {[{ cat: 'Subject-Verb Agreement', ex: 'He don\'t know → He doesn\'t know', cor: 'Use "doesn\'t" with singular subjects' },
          { cat: 'Filler Words', ex: 'Used "um" 8 times in voice answers', cor: 'Pause briefly instead of using fillers' }]
          .map(e => (
            <div key={e.cat} className="p-3 rounded-xl mb-2" style={{ background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.15)' }}>
              <p className="text-red-400 font-semibold text-sm">{e.cat}</p>
              <p className="text-slate-500 text-xs mt-0.5 font-mono">{e.ex}</p>
              <p className="text-slate-400 text-xs mt-1">💡 {e.cor}</p>
            </div>
          ))}
      </div>
    </motion.div>
  )
}

export default function CommTest() {
  const [phase, setPhase] = useState<'mcq' | 'voice' | 'results'>('mcq')
  const isPro = true

  if (!isPro) return (
    <div className="flex min-h-screen bg-surface-900">
      <SideNav />
      <main className="flex-1 flex items-center justify-center p-6"><div className="glass rounded-2xl p-10 max-w-sm text-center"><Lock size={40} className="text-brand-400 mx-auto mb-4" /><h2 className="font-display font-bold text-xl text-white mb-2">Pro Feature</h2><p className="text-slate-500 text-sm mb-6">Upgrade to Pro to access the full Communication Test.</p><button className="btn-primary w-full">Upgrade to Pro</button></div></main>
      <BottomNav />
    </div>
  )

  return (
    <div className="flex min-h-screen bg-surface-900">
      <SideNav />
      <main className="flex-1 pb-20 md:pb-0 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-6 py-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
            <span className="badge badge-brand mb-3">Communication Assessment</span>
            <h1 className="font-display font-bold text-3xl text-white mt-1">Communication Test</h1>
            {phase !== 'results' && (
              <div className="flex gap-4 mt-4">
                {[{ key: 'mcq', label: 'Part 1: MCQ' }, { key: 'voice', label: 'Part 2: Voice' }].map(p => (
                  <div key={p.key} className="flex items-center gap-2 text-sm" style={{ color: phase === p.key ? '#a5b4fc' : '#374151' }}>
                    <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: phase === p.key ? '#6366f1' : 'rgba(255,255,255,0.06)' }}>
                      {p.key === 'mcq' ? '1' : '2'}
                    </span>
                    {p.label}
                  </div>
                ))}
              </div>
            )}
          </motion.div>
          {phase === 'mcq' && <MCQSection onComplete={() => setPhase('voice')} />}
          {phase === 'voice' && <VoiceSection onComplete={() => setPhase('results')} />}
          {phase === 'results' && <ScoreResults />}
        </div>
      </main>
      <BottomNav />
    </div>
  )
}
