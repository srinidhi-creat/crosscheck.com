import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { ChevronRight, ChevronLeft, Loader2 } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuthStore } from '../store'

const QUESTIONS = [
  { id: 1, section: 'Career Goals', question: 'What is your primary career goal for the next 2 years?', type: 'radio', options: ['Get a new job', 'Get promoted', 'Switch industries', 'Start my own venture', 'Upskill / reskill'] },
  { id: 2, section: 'Career Goals', question: 'Which industry are you targeting?', type: 'radio', options: ['Software / IT', 'Finance / Banking', 'Healthcare', 'Design / Creative', 'Marketing / Growth', 'Other'] },
  { id: 3, section: 'Career Goals', question: 'What type of role interests you most?', type: 'radio', options: ['Individual Contributor', 'Team Lead / Manager', 'Consultant / Freelancer', 'Founder / Entrepreneur'] },
  { id: 4, section: 'Career Goals', question: 'How soon are you looking to make a move?', type: 'radio', options: ['Immediately', 'Within 3 months', '3–6 months', '6+ months', 'Just exploring'] },
  { id: 5, section: 'Career Goals', question: 'Are you open to relocation?', type: 'radio', options: ['Yes, anywhere', 'Yes, within my country', 'Remote only', 'No relocation'] },
  { id: 6, section: 'Experience & Education', question: 'What is your highest education level?', type: 'radio', options: ['High School / Diploma', "Bachelor's Degree", "Master's Degree", 'PhD', 'Self-taught / Bootcamp'] },
  { id: 7, section: 'Experience & Education', question: 'How many years of work experience do you have?', type: 'radio', options: ['0 (Fresher)', '0–1 year', '1–3 years', '3–6 years', '6+ years'] },
  { id: 8, section: 'Experience & Education', question: 'Do you have any certifications?', type: 'radio', options: ['Yes, industry-recognized', 'Yes, online courses only', 'No, but planning to', 'No certifications'] },
  { id: 9, section: 'Experience & Education', question: 'What is your primary domain of expertise?', type: 'text', placeholder: 'e.g., Full-stack development, Data Science, Product Management...' },
  { id: 10, section: 'Experience & Education', question: 'Are you currently employed?', type: 'radio', options: ['Yes, full-time', 'Yes, part-time', 'Freelancing', 'Currently not employed'] },
  { id: 11, section: 'Work Style', question: 'What work environment do you prefer?', type: 'radio', options: ['Remote', 'Hybrid', 'In-office', 'No preference'] },
  { id: 12, section: 'Work Style', question: 'What company size appeals to you?', type: 'radio', options: ['Startup (< 50)', 'Scale-up (50–500)', 'Enterprise (500+)', 'No preference'] },
  { id: 13, section: 'Work Style', question: 'How do you prefer to collaborate?', type: 'radio', options: ['Mostly independent', 'Small focused team', 'Large cross-functional team', 'Depends on the project'] },
  { id: 14, section: 'Work Style', question: 'How important is work-life balance to you?', type: 'radio', options: ['Extremely important', 'Important but flexible', 'I prefer high intensity', 'No strong preference'] },
  { id: 15, section: 'Work Style', question: 'What motivates you most at work?', type: 'radio', options: ['Compensation & growth', 'Learning & development', 'Impact & purpose', 'Recognition & leadership', 'Stability & security'] },
  { id: 16, section: 'Technical Skills', question: 'Rate your programming proficiency', type: 'radio', options: ['None', 'Beginner', 'Intermediate', 'Advanced', 'Expert'] },
  { id: 17, section: 'Technical Skills', question: 'Which technical areas are your strongest?', type: 'checkbox', options: ['Frontend Development', 'Backend Development', 'Data Science / ML', 'DevOps / Cloud', 'Mobile Development', 'Design / UI-UX', 'Cybersecurity', 'Databases'] },
  { id: 18, section: 'Technical Skills', question: 'Do you actively contribute to open-source or personal projects?', type: 'radio', options: ['Yes, actively', 'Occasionally', 'Rarely / Never'] },
  { id: 19, section: 'Technical Skills', question: 'List your top 3 technical skills', type: 'text', placeholder: 'e.g., Python, React, PostgreSQL' },
  { id: 20, section: 'Technical Skills', question: 'How do you typically keep your skills updated?', type: 'radio', options: ['Online courses (Udemy, Coursera)', 'YouTube / Blogs', 'Books & documentation', 'Side projects', 'Company training'] },
  { id: 21, section: 'Communication', question: 'How confident are you in written English communication?', type: 'radio', options: ['Very confident', 'Confident', 'Somewhat confident', 'Need improvement'] },
  { id: 22, section: 'Communication', question: 'How confident are you in spoken English communication?', type: 'radio', options: ['Very confident', 'Confident', 'Somewhat confident', 'Need improvement'] },
  { id: 23, section: 'Communication', question: 'Have you given any public talks or presentations?', type: 'radio', options: ['Yes, frequently', 'Yes, occasionally', 'No, but open to it', 'No, prefer not to'] },
  { id: 24, section: 'Communication', question: 'How comfortable are you with professional email etiquette?', type: 'radio', options: ['Very comfortable', 'Comfortable', 'Somewhat comfortable', 'Need to improve'] },
  { id: 25, section: 'Communication', question: 'Have you worked in an international/multicultural team?', type: 'radio', options: ['Yes, extensively', 'Yes, occasionally', 'No, but interested', 'No, and not a priority'] },
  { id: 26, section: 'Salary & Location', question: 'What is your current annual salary (INR LPA)?', type: 'radio', options: ['I am a Fresher', '0–4 LPA', '4–8 LPA', '8–15 LPA', '15–25 LPA', '25+ LPA'] },
  { id: 27, section: 'Salary & Location', question: 'What annual salary are you targeting (INR LPA)?', type: 'radio', options: ['0–4 LPA', '4–8 LPA', '8–15 LPA', '15–25 LPA', '25–40 LPA', '40+ LPA'] },
  { id: 28, section: 'Salary & Location', question: 'What is your current city / location?', type: 'text', placeholder: 'e.g., Bangalore, Mumbai, Remote...' },
  { id: 29, section: 'Salary & Location', question: 'Would you consider contract / freelance arrangements?', type: 'radio', options: ['Yes, prefer it', 'Open to it', 'Prefer full-time only', 'Not sure'] },
  { id: 30, section: 'Salary & Location', question: 'Anything else you want us to know about your career preferences?', type: 'text', placeholder: 'Optional — share any additional context...' },
]

const SECTIONS = [...new Set(QUESTIONS.map(q => q.section))]

export default function PersonalQuestions() {
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const [answers, setAnswers] = useState<Record<number, string | string[]>>({})
  const [currentIndex, setCurrentIndex] = useState(0)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const q = QUESTIONS[currentIndex]
  const sectionIndex = SECTIONS.indexOf(q.section)
  const answered = Object.keys(answers).length

  const setAnswer = (val: string | string[]) => setAnswers(prev => ({ ...prev, [q.id]: val }))

  const handleCheckbox = (option: string) => {
    const current = (answers[q.id] as string[]) || []
    const updated = current.includes(option) ? current.filter(o => o !== option) : [...current, option]
    setAnswer(updated)
  }

  const next = () => { if (currentIndex < QUESTIONS.length - 1) setCurrentIndex(i => i + 1) }
  const prev = () => { if (currentIndex > 0) setCurrentIndex(i => i - 1) }

  const submit = async () => {
    if (!user?.id) return
    setSaving(true); setError('')
    try {
      const { error: upsertError } = await supabase
        .from('onboarding_answers')
        .upsert({ user_id: user.id, answers }, { onConflict: 'user_id' })
      if (upsertError) throw upsertError
      navigate('/home')
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-surface-900 flex flex-col relative overflow-hidden">
      <div className="glow-orb w-80 h-80 bg-brand-600 opacity-10 top-0 right-0 animate-glow-pulse" />
      <div className="absolute inset-0 bg-grid-pattern pointer-events-none" />

      {/* Top progress */}
      <div className="relative z-10 px-6 pt-6">
        <div className="max-w-xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 text-xs font-medium uppercase tracking-wider">{q.section}</span>
            <span className="text-slate-500 text-xs">{currentIndex + 1} / {QUESTIONS.length}</span>
          </div>
          <div className="h-1.5 bg-surface-600 rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: 'linear-gradient(90deg, #6366f1, #34d399)' }}
              animate={{ width: `${((currentIndex + 1) / QUESTIONS.length) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
          <div className="flex gap-1.5 mt-3">
            {SECTIONS.map((s, i) => (
              <div key={s} className="flex-1 h-1 rounded-full transition-all duration-300"
                style={{ background: i < sectionIndex ? '#6366f1' : i === sectionIndex ? 'rgba(99,102,241,0.5)' : 'rgba(255,255,255,0.08)' }} />
            ))}
          </div>
        </div>
      </div>

      {/* Question card */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-xl">
          <AnimatePresence mode="wait">
            <motion.div
              key={q.id}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.25 }}
              className="glass rounded-2xl p-8"
            >
              <p className="text-slate-500 text-xs uppercase tracking-wider mb-2">Question {currentIndex + 1}</p>
              <h2 className="font-display font-semibold text-xl text-white mb-6 leading-relaxed">{q.question}</h2>

              {q.type === 'radio' && (
                <div className="space-y-2.5">
                  {q.options?.map(opt => (
                    <button key={opt} type="button"
                      onClick={() => setAnswer(opt)}
                      className="w-full text-left px-4 py-3 rounded-xl text-sm transition-all duration-150"
                      style={{
                        background: answers[q.id] === opt ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.04)',
                        border: answers[q.id] === opt ? '1.5px solid #6366f1' : '1px solid rgba(255,255,255,0.08)',
                        color: answers[q.id] === opt ? '#c7d2fe' : '#94a3b8',
                      }}>
                      <span className="inline-flex items-center gap-2">
                        <span className="w-4 h-4 rounded-full border flex items-center justify-center shrink-0"
                          style={{ borderColor: answers[q.id] === opt ? '#6366f1' : '#374151' }}>
                          {answers[q.id] === opt && <span className="w-2 h-2 rounded-full bg-brand-500" />}
                        </span>
                        {opt}
                      </span>
                    </button>
                  ))}
                </div>
              )}

              {q.type === 'checkbox' && (
                <div className="grid grid-cols-2 gap-2">
                  {q.options?.map(opt => {
                    const checked = ((answers[q.id] as string[]) || []).includes(opt)
                    return (
                      <button key={opt} type="button"
                        onClick={() => handleCheckbox(opt)}
                        className="text-left px-3 py-2.5 rounded-xl text-sm transition-all duration-150"
                        style={{
                          background: checked ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.04)',
                          border: checked ? '1.5px solid #6366f1' : '1px solid rgba(255,255,255,0.08)',
                          color: checked ? '#c7d2fe' : '#94a3b8',
                        }}>
                        <span className="inline-flex items-center gap-2">
                          <span className="w-4 h-4 rounded border flex items-center justify-center shrink-0"
                            style={{ borderColor: checked ? '#6366f1' : '#374151', background: checked ? '#6366f1' : 'transparent' }}>
                            {checked && <span className="text-white text-xs">✓</span>}
                          </span>
                          {opt}
                        </span>
                      </button>
                    )
                  })}
                </div>
              )}

              {q.type === 'text' && (
                <textarea rows={3}
                  placeholder={q.placeholder}
                  value={(answers[q.id] as string) || ''}
                  onChange={e => setAnswer(e.target.value)}
                  className="input-field resize-none" />
              )}
            </motion.div>
          </AnimatePresence>

          {error && (
            <div className="mt-4 text-red-400 text-sm text-center">{error}</div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-6">
            <button onClick={prev} disabled={currentIndex === 0}
              className="btn-outline flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed">
              <ChevronLeft size={18} /> Back
            </button>

            <span className="text-slate-600 text-xs">{answered} of {QUESTIONS.length} answered</span>

            {currentIndex < QUESTIONS.length - 1 ? (
              <button onClick={next} className="btn-primary flex items-center gap-2">
                Next <ChevronRight size={18} />
              </button>
            ) : (
              <button onClick={submit} id="submit-onboarding" disabled={saving}
                className="btn-primary flex items-center gap-2">
                {saving ? <><Loader2 size={16} className="animate-spin" /> Saving…</> : <>Submit Answers <ChevronRight size={18} /></>}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
