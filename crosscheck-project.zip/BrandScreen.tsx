import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'

export default function BrandScreen() {
  const navigate = useNavigate()

  useEffect(() => {
    const timer = setTimeout(() => navigate('/auth'), 1500)
    return () => clearTimeout(timer)
  }, [navigate])

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center overflow-hidden relative cursor-pointer"
      style={{ background: 'linear-gradient(160deg, #0a0a0f 0%, #12121a 50%, #0d0d1a 100%)' }}
      onClick={() => navigate('/auth')}
    >
      {/* Ambient glow */}
      <div className="glow-orb w-[600px] h-[600px] bg-brand-600 opacity-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 flex flex-col items-center gap-6 text-center px-8"
      >
        {/* Logo */}
        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="w-20 h-20 flex items-center justify-center mb-2"
        >
          <img src="/logo.png" alt="CrossCheck Logo" className="w-full h-full object-contain drop-shadow-[0_0_30px_rgba(99,102,241,0.35)]" />
        </motion.div>

        {/* Wordmark */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.6 }}
          className="font-display font-black text-5xl md:text-7xl text-white tracking-tight"
        >
          Cross<span style={{ background: 'linear-gradient(90deg,#818cf8,#34d399)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Check</span>
        </motion.h1>

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="text-slate-400 text-lg md:text-2xl font-light max-w-md leading-relaxed"
        >
          Your Resume.{' '}
          <span className="text-brand-400 font-medium">Scored.</span>{' '}
          <span className="text-accent-400 font-medium">Improved.</span>{' '}
          <span className="text-white font-medium">Matched.</span>
        </motion.p>

        {/* Tap hint */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="text-slate-600 text-sm mt-4 tracking-widest uppercase"
        >
          Tap anywhere to continue
        </motion.p>

        {/* Decorative line */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="h-px w-48 mt-2"
          style={{ background: 'linear-gradient(90deg, transparent, #6366f1, transparent)' }}
        />
      </motion.div>

      {/* Bottom credit */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 text-slate-700 text-xs tracking-widest uppercase"
      >
        By Sri · Rishi · Arkesh · Likith
      </motion.p>
    </div>
  )
}
