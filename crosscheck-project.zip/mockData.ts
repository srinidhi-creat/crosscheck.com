// Auto-generated mock data from Kaggle dataset

export const MOCK_CANDIDATES = [
  {
    "id": 1,
    "name": "Sai Das",
    "title": "AI Engineer - Experienced",
    "score": 79,
    "potential": 84,
    "commScore": 51,
    "exp": "Junior (2 yrs)",
    "skills": [
      "MLOps",
      "Cloud",
      "NLP",
      "Deep Learning",
      "Senior-Level",
      "ML",
      "AI"
    ],
    "location": "Pune",
    "edu": "Any",
    "salary": "23 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 2,
    "name": "Swati Menon",
    "title": "Digital Marketing Specialist",
    "score": 51,
    "potential": 57,
    "commScore": 92,
    "exp": "Mid (6 yrs)",
    "skills": [
      "Marketing Automation",
      "Digital Marketing",
      "SEO",
      "SEM",
      "PPC",
      "Brand Management"
    ],
    "location": "Chennai",
    "edu": "Master's",
    "salary": "28 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 3,
    "name": "Rohan Menon",
    "title": "UI Designer",
    "score": 90,
    "potential": 100,
    "commScore": 86,
    "exp": "Junior (1 yrs)",
    "skills": [
      "Usability Testing",
      "Prototyping",
      "Figma",
      "Design Systems",
      "Branding",
      "Interaction Design"
    ],
    "location": "Gurgaon",
    "edu": "Bachelor's",
    "salary": "32 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 4,
    "name": "Aarav Nair",
    "title": "QA Engineer - Fresher",
    "score": 86,
    "potential": 96,
    "commScore": 90,
    "exp": "Mid (6 yrs)",
    "skills": [
      "QA",
      "Software Testing",
      "Hyderabad",
      "Manual Testing",
      "Fresher",
      "Automation"
    ],
    "location": "Delhi",
    "edu": "Any",
    "salary": "21 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 5,
    "name": "Diya Rao",
    "title": "Marketing Specialist",
    "score": 55,
    "potential": 63,
    "commScore": 67,
    "exp": "Mid (4 yrs)",
    "skills": [
      "Digital Marketing",
      "SEO",
      "Email Marketing"
    ],
    "location": "Delhi",
    "edu": "PhD",
    "salary": "39 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 6,
    "name": "Ananya Iyer",
    "title": "Operations Manager",
    "score": 77,
    "potential": 89,
    "commScore": 86,
    "exp": "Junior (2 yrs)",
    "skills": [
      "Six Sigma",
      "Lean Management",
      "Team Leadership",
      "Operations Management",
      "Process Automation",
      "Strategic Planning",
      "Budgeting",
      "KPI Tracking"
    ],
    "location": "Delhi",
    "edu": "PhD",
    "salary": "7 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 7,
    "name": "Meera Iyer",
    "title": "Project Manager",
    "score": 82,
    "potential": 93,
    "commScore": 92,
    "exp": "Mid (6 yrs)",
    "skills": [
      "Agile",
      "Microsoft Project",
      "Project Planning"
    ],
    "location": "Remote",
    "edu": "Any",
    "salary": "15 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 8,
    "name": "Om Kumar",
    "title": "QA Engineer - Fresher",
    "score": 45,
    "potential": 59,
    "commScore": 85,
    "exp": "Mid (4 yrs)",
    "skills": [
      "Pune",
      "QA",
      "Software Testing",
      "Fresher",
      "Automation",
      "Manual Testing"
    ],
    "location": "Remote",
    "edu": "Any",
    "salary": "22 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 9,
    "name": "Priya Reddy",
    "title": "Infrastructure Network Engineer",
    "score": 86,
    "potential": 94,
    "commScore": 78,
    "exp": "Junior (2 yrs)",
    "skills": [
      "Python",
      "LAN/WAN",
      "QoS",
      "Cisco Prime"
    ],
    "location": "Delhi",
    "edu": "Master's",
    "salary": "31 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 10,
    "name": "Aditya Gupta",
    "title": "Python Developer",
    "score": 51,
    "potential": 58,
    "commScore": 85,
    "exp": "Junior (1 yrs)",
    "skills": [
      "TensorFlow",
      "Async Programming",
      "Data Science",
      "Django"
    ],
    "location": "Mumbai",
    "edu": "PhD",
    "salary": "13 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 11,
    "name": "Kavya Gupta",
    "title": "Java Developer",
    "score": 64,
    "potential": 76,
    "commScore": 75,
    "exp": "Junior (1 yrs)",
    "skills": [
      "Angular",
      "SOAP",
      "REST APIs",
      "Java",
      "NoSQL"
    ],
    "location": "Bangalore",
    "edu": "Master's",
    "salary": "21 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 12,
    "name": "Sai Gupta",
    "title": "QA Engineer - Experienced",
    "score": 63,
    "potential": 71,
    "commScore": 82,
    "exp": "Junior (3 yrs)",
    "skills": [
      "Senior-Level",
      "Automation",
      "Leadership",
      "QA",
      "CI/CD"
    ],
    "location": "Remote",
    "edu": "PhD",
    "salary": "13 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 13,
    "name": "Suhana Sharma",
    "title": "Operations Manager",
    "score": 69,
    "potential": 79,
    "commScore": 53,
    "exp": "Senior (10 yrs)",
    "skills": [
      "Six Sigma",
      "ERP",
      "Lean Management"
    ],
    "location": "Gurgaon",
    "edu": "Diploma",
    "salary": "35 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 14,
    "name": "Neha Patel",
    "title": "Operations Manager",
    "score": 82,
    "potential": 89,
    "commScore": 52,
    "exp": "Junior (3 yrs)",
    "skills": [
      "Data Analysis",
      "Team Leadership",
      "Cross-Functional Collaboration"
    ],
    "location": "Hyderabad",
    "edu": "Master's",
    "salary": "8 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 15,
    "name": "Neha Rao",
    "title": "Product Designer",
    "score": 81,
    "potential": 89,
    "commScore": 75,
    "exp": "Mid (6 yrs)",
    "skills": [
      "User Research",
      "Product Design",
      "UI/UX Design"
    ],
    "location": "Chennai",
    "edu": "PhD",
    "salary": "35 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 16,
    "name": "Sai Joshi",
    "title": "Marketing Specialist",
    "score": 68,
    "potential": 73,
    "commScore": 81,
    "exp": "Senior (9 yrs)",
    "skills": [
      "Email Marketing",
      "SEM",
      "Content Marketing",
      "PPC",
      "Leadership",
      "Analytics",
      "SEO",
      "AI Marketing Tools"
    ],
    "location": "Mumbai",
    "edu": "Master's",
    "salary": "8 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 17,
    "name": "Neha Joshi",
    "title": "Java Developer",
    "score": 48,
    "potential": 57,
    "commScore": 91,
    "exp": "Senior (9 yrs)",
    "skills": [
      "MongoDB",
      "SQL",
      "Performance Tuning",
      "Java",
      "NoSQL"
    ],
    "location": "Delhi",
    "edu": "Diploma",
    "salary": "34 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 18,
    "name": "Ananya Iyer",
    "title": "Market Research Analyst",
    "score": 64,
    "potential": 74,
    "commScore": 73,
    "exp": "Mid (5 yrs)",
    "skills": [
      "Survey Design",
      "Market Research",
      "Report Writing",
      "Consumer Behavior",
      "Qualitative Research",
      "Critical Thinking",
      "Excel"
    ],
    "location": "Remote",
    "edu": "PhD",
    "salary": "3 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 19,
    "name": "Aditya Sharma",
    "title": "Robotics Engineer",
    "score": 63,
    "potential": 70,
    "commScore": 74,
    "exp": "Junior (3 yrs)",
    "skills": [
      "C++",
      "CAD",
      "Leadership",
      "ROS"
    ],
    "location": "Bangalore",
    "edu": "Bachelor's",
    "salary": "30 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 20,
    "name": "Meera Patel",
    "title": "Operations Manager",
    "score": 84,
    "potential": 96,
    "commScore": 59,
    "exp": "Senior (7 yrs)",
    "skills": [
      "Workflow Automation",
      "Process Optimization",
      "KPI Tracking"
    ],
    "location": "Gurgaon",
    "edu": "Diploma",
    "salary": "34 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 21,
    "name": "Priya Kumar",
    "title": "Operations Manager",
    "score": 62,
    "potential": 70,
    "commScore": 70,
    "exp": "Junior (1 yrs)",
    "skills": [
      "Process Observation",
      "Operations Management",
      "Time Management",
      "Team Coordination"
    ],
    "location": "Bangalore",
    "edu": "Master's",
    "salary": "3 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 22,
    "name": "Sai Gupta",
    "title": "QA Engineer - Experienced",
    "score": 64,
    "potential": 78,
    "commScore": 59,
    "exp": "Junior (2 yrs)",
    "skills": [
      "Strategy",
      "Senior-Level",
      "QA"
    ],
    "location": "Pune",
    "edu": "Bachelor's",
    "salary": "27 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 23,
    "name": "Ananya Joshi",
    "title": "Java Developer",
    "score": 67,
    "potential": 80,
    "commScore": 83,
    "exp": "Junior (1 yrs)",
    "skills": [
      "Selenium",
      "Mockito",
      "JUnit",
      "Agile",
      "Java"
    ],
    "location": "Gurgaon",
    "edu": "Master's",
    "salary": "29 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 24,
    "name": "Om Rao",
    "title": "JavaScript Developer",
    "score": 53,
    "potential": 68,
    "commScore": 74,
    "exp": "Mid (6 yrs)",
    "skills": [
      "CI/CD",
      "Jest",
      "Docker",
      "JavaScript",
      "Webpack"
    ],
    "location": "Pune",
    "edu": "Master's",
    "salary": "26 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 25,
    "name": "Aditya Nair",
    "title": "QA Engineer - Experienced",
    "score": 94,
    "potential": 100,
    "commScore": 70,
    "exp": "Senior (10 yrs)",
    "skills": [
      "Senior-Level",
      "Performance Testing",
      "Automation",
      "QA",
      "New York",
      "Software",
      "CI/CD"
    ],
    "location": "Pune",
    "edu": "Any",
    "salary": "8 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 26,
    "name": "Om Reddy",
    "title": "Robotics Engineer",
    "score": 58,
    "potential": 67,
    "commScore": 57,
    "exp": "Mid (4 yrs)",
    "skills": [
      "Python",
      "Machine Learning",
      "Leadership",
      "Embedded Systems",
      "C++",
      "CAD",
      "MATLAB",
      "Sensors"
    ],
    "location": "Delhi",
    "edu": "Diploma",
    "salary": "20 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 27,
    "name": "Kabir Gupta",
    "title": "Product Designer",
    "score": 70,
    "potential": 79,
    "commScore": 70,
    "exp": "Senior (8 yrs)",
    "skills": [
      "Design Systems",
      "Figma",
      "Product Design Strategy",
      "Agile",
      "A/B Testing",
      "UI/UX Design"
    ],
    "location": "Pune",
    "edu": "Bachelor's",
    "salary": "31 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 28,
    "name": "Aarav Nair",
    "title": "Java Developer",
    "score": 84,
    "potential": 99,
    "commScore": 86,
    "exp": "Senior (10 yrs)",
    "skills": [
      "Java",
      "Core Java",
      "Teamwork",
      "Git",
      "Collections",
      "OOP"
    ],
    "location": "Bangalore",
    "edu": "PhD",
    "salary": "39 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 29,
    "name": "Ananya Gupta",
    "title": "Product Designer",
    "score": 61,
    "potential": 72,
    "commScore": 54,
    "exp": "Senior (7 yrs)",
    "skills": [
      "Product Design",
      "UI/UX Design",
      "Wireframing"
    ],
    "location": "Chennai",
    "edu": "Diploma",
    "salary": "26 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 30,
    "name": "Vihaan Joshi",
    "title": "Market Research Analyst",
    "score": 61,
    "potential": 67,
    "commScore": 81,
    "exp": "Mid (5 yrs)",
    "skills": [
      "Qualitative Research",
      "Report Writing",
      "Data Analysis",
      "Consumer Behavior",
      "Critical Thinking",
      "Data Visualization",
      "Survey Design",
      "Excel"
    ],
    "location": "Pune",
    "edu": "PhD",
    "salary": "20 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 31,
    "name": "Vihaan Menon",
    "title": "Java Developer",
    "score": 74,
    "potential": 85,
    "commScore": 67,
    "exp": "Senior (9 yrs)",
    "skills": [
      "JUnit",
      "Testing",
      "File Handling",
      "Java"
    ],
    "location": "Chennai",
    "edu": "Any",
    "salary": "38 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 32,
    "name": "Kavya Kumar",
    "title": "Product Designer",
    "score": 46,
    "potential": 61,
    "commScore": 54,
    "exp": "Senior (10 yrs)",
    "skills": [
      "Prototyping",
      "User Research",
      "Wireframing",
      "Sketch"
    ],
    "location": "Chennai",
    "edu": "Any",
    "salary": "7 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 33,
    "name": "Kabir Singh",
    "title": "Python Developer",
    "score": 64,
    "potential": 71,
    "commScore": 77,
    "exp": "Junior (1 yrs)",
    "skills": [
      "Docker",
      "REST APIs",
      "Python",
      "Django",
      "Data Science"
    ],
    "location": "Gurgaon",
    "edu": "PhD",
    "salary": "30 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 34,
    "name": "Swati Iyer",
    "title": "Python Developer",
    "score": 56,
    "potential": 61,
    "commScore": 82,
    "exp": "Junior (1 yrs)",
    "skills": [
      "SQL",
      "Git",
      "OOP",
      "NumPy",
      "Python"
    ],
    "location": "Delhi",
    "edu": "Any",
    "salary": "25 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 35,
    "name": "Aditya Menon",
    "title": "Market Research Analyst",
    "score": 93,
    "potential": 100,
    "commScore": 54,
    "exp": "Senior (8 yrs)",
    "skills": [
      "Report Writing",
      "Excel",
      "Survey Design",
      "Qualitative Research",
      "Consumer Behavior",
      "Data Visualization"
    ],
    "location": "Chennai",
    "edu": "Diploma",
    "salary": "25 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 36,
    "name": "Ananya Iyer",
    "title": "Marketing Specialist",
    "score": 86,
    "potential": 95,
    "commScore": 75,
    "exp": "Senior (10 yrs)",
    "skills": [
      "Analytics",
      "Lead Generation",
      "SEO",
      "Digital Marketing",
      "Content Creation",
      "SEM",
      "Brand Management"
    ],
    "location": "Remote",
    "edu": "Bachelor's",
    "salary": "9 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 37,
    "name": "Kavya Iyer",
    "title": "Lead Network Engineer",
    "score": 92,
    "potential": 100,
    "commScore": 61,
    "exp": "Senior (9 yrs)",
    "skills": [
      "Lead Engineer",
      "Cisco Nexus",
      "MPLS",
      "Leadership"
    ],
    "location": "Hyderabad",
    "edu": "Master's",
    "salary": "32 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 38,
    "name": "Ananya Singh",
    "title": "Python Developer",
    "score": 94,
    "potential": 100,
    "commScore": 74,
    "exp": "Junior (2 yrs)",
    "skills": [
      "OOP",
      "Python",
      "SQL"
    ],
    "location": "Remote",
    "edu": "Bachelor's",
    "salary": "31 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 39,
    "name": "Om Joshi",
    "title": "Java Developer",
    "score": 72,
    "potential": 86,
    "commScore": 50,
    "exp": "Senior (8 yrs)",
    "skills": [
      "Spring",
      "Maven",
      "TestNG",
      "Java",
      "Hibernate",
      "JUnit"
    ],
    "location": "Pune",
    "edu": "Any",
    "salary": "21 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 40,
    "name": "Vihaan Singh",
    "title": "Robotics Engineer",
    "score": 60,
    "potential": 68,
    "commScore": 92,
    "exp": "Senior (10 yrs)",
    "skills": [
      "Sensors",
      "C++",
      "Control Systems",
      "Python",
      "Problem Solving",
      "Embedded Systems",
      "CAD",
      "MATLAB"
    ],
    "location": "Gurgaon",
    "edu": "Any",
    "salary": "37 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 41,
    "name": "Vihaan Rao",
    "title": "Software Tester (SDET)",
    "score": 85,
    "potential": 96,
    "commScore": 95,
    "exp": "Fresher",
    "skills": [
      "JUnit",
      "Selenium",
      "Agile/Scrum",
      "Software Testing",
      "Regression Testing",
      "API Testing",
      "Automation Testing"
    ],
    "location": "Chennai",
    "edu": "Diploma",
    "salary": "5 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 42,
    "name": "Sai Joshi",
    "title": "Java Developer",
    "score": 92,
    "potential": 100,
    "commScore": 52,
    "exp": "Senior (7 yrs)",
    "skills": [
      "System Design",
      "Java",
      "Spring Boot",
      "Microservices"
    ],
    "location": "Hyderabad",
    "edu": "PhD",
    "salary": "40 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 43,
    "name": "Meera Menon",
    "title": "Software Engineer - Experienced",
    "score": 49,
    "potential": 58,
    "commScore": 87,
    "exp": "Mid (6 yrs)",
    "skills": [
      "Software Engineer",
      "Python",
      "Machine Learning",
      "REST APIs"
    ],
    "location": "Pune",
    "edu": "Any",
    "salary": "19 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 44,
    "name": "Sai Reddy",
    "title": "Cloud Security Analyst",
    "score": 86,
    "potential": 91,
    "commScore": 51,
    "exp": "Junior (2 yrs)",
    "skills": [
      "Cloud Security",
      "Penetration Testing",
      "Compliance"
    ],
    "location": "Chennai",
    "edu": "Bachelor's",
    "salary": "17 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 45,
    "name": "Suhana Sharma",
    "title": "Product Designer",
    "score": 79,
    "potential": 87,
    "commScore": 62,
    "exp": "Fresher",
    "skills": [
      "User Research",
      "Figma",
      "Wireframing",
      "Product Design",
      "Prototyping"
    ],
    "location": "Hyderabad",
    "edu": "Master's",
    "salary": "22 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 46,
    "name": "Om Patel",
    "title": "Marketing Specialist",
    "score": 83,
    "potential": 90,
    "commScore": 79,
    "exp": "Senior (7 yrs)",
    "skills": [
      "Content Creation",
      "PPC",
      "Google Analytics",
      "Email Marketing",
      "Marketing Automation",
      "SEM"
    ],
    "location": "Gurgaon",
    "edu": "PhD",
    "salary": "14 LPA",
    "availability": "Immediate",
    "shortlisted": false
  },
  {
    "id": 47,
    "name": "Vihaan Reddy",
    "title": "QA Engineer - Fresher",
    "score": 75,
    "potential": 80,
    "commScore": 88,
    "exp": "Senior (8 yrs)",
    "skills": [
      "QA",
      "Software Testing",
      "Automation",
      "Fresher"
    ],
    "location": "Chennai",
    "edu": "Bachelor's",
    "salary": "39 LPA",
    "availability": "15 days",
    "shortlisted": false
  },
  {
    "id": 48,
    "name": "Sai Gupta",
    "title": "Robotics Engineer",
    "score": 62,
    "potential": 68,
    "commScore": 55,
    "exp": "Mid (6 yrs)",
    "skills": [
      "Machine Learning",
      "CAD",
      "MATLAB",
      "Python",
      "Control Systems",
      "ROS"
    ],
    "location": "Bangalore",
    "edu": "Diploma",
    "salary": "31 LPA",
    "availability": "60+ days",
    "shortlisted": false
  },
  {
    "id": 49,
    "name": "Swati Gupta",
    "title": "SEO Specialist",
    "score": 87,
    "potential": 99,
    "commScore": 58,
    "exp": "Senior (8 yrs)",
    "skills": [
      "Page Speed",
      "Link Building",
      "Local SEO",
      "Visual Search",
      "Schema Markup",
      "Voice Search",
      "AI SEO Tools",
      "Content Optimization"
    ],
    "location": "Remote",
    "edu": "Any",
    "salary": "37 LPA",
    "availability": "30 days",
    "shortlisted": false
  },
  {
    "id": 50,
    "name": "Diya Patel",
    "title": ".NET Developer",
    "score": 92,
    "potential": 100,
    "commScore": 68,
    "exp": "Mid (4 yrs)",
    "skills": [
      ".NET",
      "C#",
      "SQL Server",
      "ASP.NET"
    ],
    "location": "Bangalore",
    "edu": "Diploma",
    "salary": "39 LPA",
    "availability": "60+ days",
    "shortlisted": false
  }
];

export const MOCK_COMPANIES = [
  {
    "name": "Paytm",
    "match": 89,
    "role": "Copywriter",
    "skills": [
      "Leadership",
      "Content Strategy",
      "Digital Marketing"
    ]
  },
  {
    "name": "Swiggy",
    "match": 88,
    "role": "Cloud Engineer - Fresher",
    "skills": [
      "DevOps",
      "Cloud",
      "Entry-Level",
      "Remote",
      "Containerization"
    ]
  },
  {
    "name": "CRED",
    "match": 81,
    "role": "SEO Specialist",
    "skills": [
      "Search Console",
      "SEO Strategy",
      "Technical SEO",
      "Content Optimization"
    ]
  },
  {
    "name": "ThoughtWorks",
    "match": 75,
    "role": "Sales Executive",
    "skills": [
      "Sales Forecasting",
      "Lead Generation",
      "CRM"
    ]
  },
  {
    "name": "Swiggy",
    "match": 67,
    "role": ".NET Developer",
    "skills": [
      ".NET Core",
      "Angular",
      "SQL Server",
      "ASP.NET MVC",
      "C#"
    ]
  },
  {
    "name": "CRED",
    "match": 93,
    "role": "Copywriter",
    "skills": [
      "Digital Marketing",
      "Brand Voice",
      "Collaboration",
      "SEO"
    ]
  },
  {
    "name": "Atlassian",
    "match": 76,
    "role": "Software Tester (SDET)",
    "skills": [
      "Selenium",
      "Agile/Scrum",
      "Software Testing"
    ]
  },
  {
    "name": "Zepto",
    "match": 73,
    "role": "Product Designer",
    "skills": [
      "Adobe Illustrator",
      "Product Design",
      "User Flows",
      "Typography"
    ]
  },
  {
    "name": "CRED",
    "match": 81,
    "role": "Principal Android Engineer",
    "skills": [
      "Room",
      "Unit Testing",
      "CI/CD",
      "Android NDK"
    ]
  },
  {
    "name": "CRED",
    "match": 90,
    "role": "SEO Specialist",
    "skills": [
      "Voice Search",
      "Page Speed",
      "Analytics",
      "Visual Search",
      "Schema Markup"
    ]
  },
  {
    "name": "Uber",
    "match": 83,
    "role": "Product Manager",
    "skills": [
      "Data-Driven Decisions",
      "Growth Metrics",
      "Stakeholder Management",
      "Roadmapping",
      "Product Strategy"
    ]
  },
  {
    "name": "Ola",
    "match": 79,
    "role": "Software Tester (SDET)",
    "skills": [
      "Software Testing",
      "Automation Testing",
      "TestNG",
      "API Testing",
      "Selenium"
    ]
  },
  {
    "name": "Google",
    "match": 89,
    "role": "JavaScript Developer",
    "skills": [
      "CI/CD",
      "React",
      "TypeScript"
    ]
  },
  {
    "name": "Paytm",
    "match": 74,
    "role": "Big Data Specialist",
    "skills": [
      "Big Data",
      "Hadoop",
      "SQL",
      "Machine Learning",
      "Spark Streaming"
    ]
  },
  {
    "name": "Uber",
    "match": 92,
    "role": "Java Developer",
    "skills": [
      "Spring Boot",
      "SQL",
      "Java Developer",
      "REST APIs",
      "Hibernate"
    ]
  },
  {
    "name": "Razorpay",
    "match": 85,
    "role": "Content Writer",
    "skills": [
      "Multi-format Content",
      "AI Tools",
      "Editing",
      "Analytics",
      "Project Management"
    ]
  },
  {
    "name": "Uber",
    "match": 88,
    "role": "Copywriter",
    "skills": [
      "AI Tools",
      "Project Management",
      "Digital Marketing",
      "Editing"
    ]
  },
  {
    "name": "Microsoft",
    "match": 67,
    "role": "Data Analyst - Experienced",
    "skills": [
      "Data Analytics",
      "BI",
      "Dashboards",
      "Predictive Modeling",
      "Senior-Level"
    ]
  },
  {
    "name": "Razorpay",
    "match": 96,
    "role": "Product Manager",
    "skills": [
      "Agile",
      "Product Management",
      "Market Research",
      "Customer Interviews",
      "User Experience"
    ]
  },
  {
    "name": "Microsoft",
    "match": 91,
    "role": "Digital Marketing Specialist",
    "skills": [
      "SEO",
      "Brand Management",
      "Campaign Management",
      "SEM"
    ]
  },
  {
    "name": "Google",
    "match": 82,
    "role": "Graduate Security Analyst",
    "skills": [
      "Incident Response",
      "Malware Analysis",
      "Network Security"
    ]
  },
  {
    "name": "Atlassian",
    "match": 82,
    "role": "Lead Data Scientist",
    "skills": [
      "Big Data",
      "Python",
      "Machine Learning"
    ]
  },
  {
    "name": "Flipkart",
    "match": 73,
    "role": "Sales Executive",
    "skills": [
      "Sales Executive",
      "CRM",
      "Social Selling",
      "Predictive Analytics",
      "Sales Automation"
    ]
  },
  {
    "name": "Swiggy",
    "match": 86,
    "role": "Solutions Architect",
    "skills": [
      "Cloud Computing",
      "AWS",
      "Azure",
      "GCP"
    ]
  },
  {
    "name": "Google",
    "match": 80,
    "role": "Principal Android Developer",
    "skills": [
      "Room",
      "MVVM",
      "Unit Testing"
    ]
  },
  {
    "name": "Zepto",
    "match": 96,
    "role": "Ethical Hacker",
    "skills": [
      "Network Security",
      "Windows Security",
      "Malware Analysis",
      "Metasploit"
    ]
  },
  {
    "name": "Ola",
    "match": 86,
    "role": "Data Engineer",
    "skills": [
      "Python",
      "Spark Basics",
      "Azure"
    ]
  },
  {
    "name": "CRED",
    "match": 69,
    "role": "AR/VR Developer",
    "skills": [
      "ARCore",
      "ARKit",
      "C#",
      "Performance Optimization"
    ]
  },
  {
    "name": "Zomato",
    "match": 97,
    "role": "Network Engineer",
    "skills": [
      "MPLS",
      "OSPF",
      "BGP",
      "QoS",
      "Cisco Nexus"
    ]
  },
  {
    "name": "Zomato",
    "match": 92,
    "role": "Cybersecurity Analyst",
    "skills": [
      "Network Security",
      "Penetration Testing",
      "Vulnerability Assessment"
    ]
  }
];
