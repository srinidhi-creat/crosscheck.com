# Supabase Authentication Setup Guide

## Issues Fixed in AuthScreen.tsx

✅ **Added timeout safeguards** (15 seconds) to prevent infinite loading states
✅ **Improved error handling** with specific messages for email confirmation
✅ **Added console logging** for debugging failed requests  
✅ **Fixed missing navigation** in EmployerPanel when profile doesn't exist
✅ **Added email confirmation detection** to show proper user feedback
✅ **Fixed form reset** after successful sign-up

---

## Email Confirmation Configuration

### Check Current Setting in Supabase Dashboard:

1. Go to https://supabase.com → Your Project → Authentication → Email Templates
2. Look for "Email Confirmations" setting
3. Check if it says "Enable email confirmations"

### If Email Confirmations are ENABLED (Recommended for production):

**User Experience:**
- After sign-up, user sees: "Check your email to confirm, then Sign In below"
- User must click confirmation link before they can sign in
- If they try to sign in without confirming, they get: "Please confirm your email before signing in"

**What You Need to Do:**
- Ensure `SMTP` or `SendGrid` is configured in Supabase Email Settings
- Test email sending works: Create a test account and check your email inbox

### If You Want to DISABLE Email Confirmations (Development Only):

1. Go to Supabase Dashboard → Authentication → Email Templates
2. Under "Email Confirmations", toggle it OFF
3. Save changes

**After disabling:**
- Users won't receive confirmation emails
- They can sign in immediately after sign-up
- Users can update their email without confirmation

**⚠️ Warning:** Only disable for development/testing. Always enable for production!

---

## Testing the Login Flow

### Step 1: Test with a New Account
```
Email: test@example.com
Password: TestPassword123
```

### Step 2: Check Browser Console
- Open DevTools (F12)
- Go to Console tab
- Sign in and check for any error messages logged

### Step 3: Verify Supabase Connection
The app logs errors like:
```
Sign in error: Invalid login credentials
```

If you see connection errors instead, check:
1. `.env.local` has correct `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
2. Supabase project is not paused
3. RLS policies allow `select` on the `profiles` table

---

## Common Issues & Solutions

### Issue: "Login took too long" message appears

**Cause:** Network timeout or database query hanging

**Solution:**
1. Check browser DevTools Network tab for slow requests
2. Verify Supabase project health: https://supabase.com/dashboard → Project Status
3. Check RLS policies on `profiles` table (should allow authenticated users to select)

---

### Issue: "Email not confirmed" error after sign-in

**Cause:** Email confirmations are enabled, user hasn't confirmed their email

**Solution:**
- Check user's email inbox for confirmation link
- If no email received, check Supabase Email Settings are configured
- Or disable email confirmations if not needed for development

---

### Issue: "Sign in failed: no user returned"

**Cause:** Supabase auth returned empty user object

**Solution:**
1. Verify credentials are correct
2. Check if user account actually exists in Supabase
3. Check Supabase Auth table isn't deleted

---

### Issue: "Profile fetch error"

**Cause:** User exists in auth, but profile doesn't exist in `profiles` table yet

**Expected Behavior:** App navigates to `/onboarding/tier` to create profile

**If Normal:** This is expected for new accounts. The AuthListener will create profile on first login.

---

## Debugging Checklist

- [ ] Check `.env.local` credentials are correct
- [ ] Open browser DevTools → Console tab
- [ ] Try signing in and note any error messages
- [ ] Check Supabase project is not paused
- [ ] Verify email settings: is confirmation enabled? Is SMTP configured?
- [ ] Check RLS policies on `profiles` table allow reads for authenticated users

---

## Next Steps

If problems persist:

1. **Check Supabase Logs:**
   - Supabase Dashboard → Logs → Auth Events
   - Look for failed authentication attempts

2. **Test Auth Directly:**
   - Supabase Dashboard → SQL Editor
   - Run: `SELECT * FROM auth.users;`
   - Verify your test user exists

3. **Check Network Requests:**
   - DevTools → Network tab
   - Filter for `supabase` requests
   - Look for failed POST requests to `/auth/v1/token`
