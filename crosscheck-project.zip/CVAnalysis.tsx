import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useDropzone } from 'react-dropzone'
import { Upload, Link, Search, CheckCircle2, AlertCircle, TrendingUp, TrendingDown, Target, ChevronDown, ChevronUp, Sparkles, Building2, Loader2 } from 'lucide-react'
import { SideNav, BottomNav } from './EmployeeHome'
import { supabase } from '../lib/supabase'
import { useAuthStore } from '../store'
import { MOCK_COMPANIES } from '../lib/mockData'

// ─── Circular Score Component ────────────────────────────────────────────────
function CircularScore({ score, max = 100, label, color, size = 120 }: {
  score: number; max?: number; label: string; color: string; size?: number
}) {
  const radius = (size - 16) / 2
  const circumference = 2 * Math.PI * radius
  const pct = Math.min(score / max, 1)
  const offset = circumference * (1 - pct)

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none"
            stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
          <motion.circle cx={size / 2} cy={size / 2} r={radius} fill="none"
            stroke={color} strokeWidth="8" strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1.2, ease: 'easeOut', delay: 0.3 }}
            filter={`drop-shadow(0 0 6px ${color})`} />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display font-black text-2xl text-white">{score}</span>
          <span className="text-slate-500 text-[10px]">/{max}</span>
        </div>
      </div>
      <span className="text-slate-400 text-xs text-center font-medium">{label}</span>
    </div>
  )
}

type AnalysisResult = {
  obtained: number
  potential: number
  negative: number
  breakdown: { criterion: string; score: number; max: number }[]
  improvements: string[]
  flaggedTerms: { term: string; severity: string }[]
  companies: { name: string; match: number; skills: string[] }[]
}

export default function CVAnalysis() {
  const { user } = useAuthStore()
  const [cvFile, setCvFile] = useState<File | null>(null)
  const [jdMode, setJdMode] = useState<'text' | 'file' | 'url'>('text')
  const [jdText, setJdText] = useState('')
  const [jdUrl, setJdUrl] = useState('')
  const [jdFile, setJdFile] = useState<File | null>(null)
  const [search, setSearch] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [expandSection, setExpandSection] = useState<string | null>('obtained')
  const [uploadError, setUploadError] = useState('')

  const onDrop = useCallback((files: File[]) => {
    if (files[0]) setCvFile(files[0])
  }, [])
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: { 'application/pdf': ['.pdf'], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'] },
    maxSize: 5 * 1024 * 1024, multiple: false,
  })

  const onJdDrop = useCallback((files: File[]) => {
    if (files[0]) setJdFile(files[0])
  }, [])
  const { getRootProps: getJdRootProps, getInputProps: getJdInputProps, isDragActive: isJdDragActive } = useDropzone({
    onDrop: onJdDrop, accept: { 'application/pdf': ['.pdf'], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'] },
    maxSize: 5 * 1024 * 1024, multiple: false,
  })

  const analyze = async () => {
    if (!cvFile || !user?.id) return
    setAnalyzing(true); setUploadError('')
    try {
      // 1. Upload CV to Supabase Storage
      const ext = cvFile.name.split('.').pop()
      const storagePath = `${user.id}/${Date.now()}.${ext}`
      const { error: storageError } = await supabase.storage
        .from('cvs')
        .upload(storagePath, cvFile, { upsert: true })
      if (storageError) throw new Error(`Upload failed: ${storageError.message}`)

      // 2. Generate mock analysis (replace with real AI call in production)
      const mockResult: AnalysisResult = {
        obtained: 68, potential: 85, negative: 22,
        breakdown: [
          { criterion: 'Skills Match', score: 72, max: 100 },
          { criterion: 'Experience Match', score: 65, max: 100 },
          { criterion: 'Education Match', score: 80, max: 100 },
          { criterion: 'Keyword Density', score: 58, max: 100 },
          { criterion: 'Certifications', score: 40, max: 100 },
        ],
        improvements: [
          'Add "Docker" and "Kubernetes" to your skills section',
          'Quantify your achievements — use numbers and impact metrics',
          'Include relevant certifications (AWS, GCP)',
          'Expand your summary section to match JD keywords',
        ],
        flaggedTerms: [
          { term: 'PHP', severity: 'High' },
          { term: 'jQuery', severity: 'Medium' },
          { term: 'WordPress', severity: 'Low' },
        ],
        companies: MOCK_COMPANIES.sort(() => 0.5 - Math.random()).slice(0, 3),
      }

      // 3. Save result to Supabase
      await supabase.from('cv_analyses').insert({
        user_id: user.id,
        cv_storage_path: storagePath,
        jd_text: jdText || jdUrl || null,
        result_json: mockResult,
      })

      setResult(mockResult)
    } catch (e: any) {
      setUploadError(e.message)
    } finally {
      setAnalyzing(false)
    }
  }

  return (
    <div className="flex min-h-screen bg-surface-900">
      <SideNav />
      <main className="flex-1 pb-20 md:pb-0 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-6 py-10">

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="badge badge-brand mb-3">AI Analysis</span>
            <h1 className="font-display font-bold text-3xl text-white mt-1">CV Upload &amp; Analysis</h1>
            <p className="text-slate-500 mt-1">Upload your resume and a job description to get your AI score</p>
          </motion.div>

          <div className="mt-8 space-y-6">
            {/* CV Dropzone */}
            <div>
              <label className="input-label">Your CV / Resume</label>
              <div {...getRootProps()}
                className="rounded-2xl border-2 border-dashed p-8 text-center cursor-pointer transition-all duration-200"
                style={{
                  borderColor: isDragActive ? '#6366f1' : cvFile ? '#10b981' : 'rgba(99,102,241,0.25)',
                  background: isDragActive ? 'rgba(99,102,241,0.08)' : cvFile ? 'rgba(16,185,129,0.06)' : 'rgba(255,255,255,0.02)',
                }}>
                <input {...getInputProps()} id="cv-upload-input" />
                {cvFile ? (
                  <div className="flex flex-col items-center gap-2">
                    <CheckCircle2 size={32} className="text-accent-400" />
                    <p className="text-white font-medium">{cvFile.name}</p>
                    <p className="text-slate-500 text-xs">{(cvFile.size / 1024).toFixed(0)} KB · Click to replace</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <Upload size={32} className="text-slate-600" />
                    <p className="text-slate-400 font-medium">Drag &amp; drop or click to upload</p>
                    <p className="text-slate-600 text-xs">PDF or DOCX · Max 5MB</p>
                  </div>
                )}
              </div>
            </div>

            {/* JD Input */}
            <div>
              <label className="input-label">Job Description</label>
              <div className="flex gap-1 mb-3 glass rounded-xl p-1">
                {(['text', 'file', 'url'] as const).map(m => (
                  <button key={m} onClick={() => setJdMode(m)}
                    className="flex-1 py-2 rounded-lg text-xs font-semibold capitalize transition-all"
                    style={jdMode === m ? { background: 'rgba(99,102,241,0.25)', color: '#a5b4fc' } : { color: '#64748b' }}>
                    {m === 'text' ? '📝 Paste Text' : m === 'file' ? '📄 Upload File' : '🔗 LinkedIn URL'}
                  </button>
                ))}
              </div>
              {jdMode === 'text' && (
                <textarea id="jd-textarea" rows={6} placeholder="Paste the job description here..."
                  value={jdText} onChange={e => setJdText(e.target.value)}
                  className="input-field resize-none" />
              )}
              {jdMode === 'file' && (
                <div {...getJdRootProps()} className={`glass rounded-xl p-4 text-center cursor-pointer border border-dashed transition-all ${isJdDragActive ? 'border-brand-500 bg-brand-500/10' : 'border-surface-500 hover:border-slate-400'}`}>
                  <input {...getJdInputProps()} />
                  {jdFile ? (
                    <div className="flex flex-col items-center gap-1">
                      <CheckCircle2 size={24} className="text-accent-400" />
                      <p className="text-white text-sm">{jdFile.name}</p>
                    </div>
                  ) : (
                    <>
                      <Upload size={20} className="text-slate-600 mx-auto mb-2" />
                      <p className="text-slate-500 text-sm">Upload JD as PDF or DOCX</p>
                    </>
                  )}
                </div>
              )}
              {jdMode === 'url' && (
                <div className="relative">
                  <Link size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input id="jd-url" type="url" placeholder="https://linkedin.com/jobs/view/..."
                    value={jdUrl} onChange={e => setJdUrl(e.target.value)}
                    className="input-field pl-9" />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 badge badge-brand text-[10px]">Pro</span>
                </div>
              )}
            </div>

            {/* Search */}
            <div>
              <label className="input-label">Or Search JD Templates</label>
              <div className="relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input id="jd-search" type="text" placeholder="e.g., Senior React Developer, Data Analyst..."
                  value={search} onChange={e => setSearch(e.target.value)}
                  className="input-field pl-9" />
              </div>
            </div>

            {uploadError && (
              <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">
                <AlertCircle size={14} /> {uploadError}
              </div>
            )}

            <button id="analyze-btn" onClick={analyze} disabled={!cvFile || analyzing}
              className="btn-primary w-full text-base py-4 disabled:opacity-50 disabled:cursor-not-allowed">
              {analyzing ? (
                <span className="flex items-center justify-center gap-3">
                  <Loader2 size={18} className="animate-spin" />
                  Uploading &amp; Analyzing…
                </span>
              ) : (
                <><Sparkles size={18} /> Analyze CV</>
              )}
            </button>
          </div>

          {/* Results */}
          <AnimatePresence>
            {result && (
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }} className="mt-10 space-y-6">

                <h2 className="font-display font-bold text-2xl text-white">Your Analysis Results</h2>

                <div className="glass rounded-2xl p-8">
                  <div className="flex flex-wrap justify-around gap-8">
                    <div className="flex flex-col items-center gap-3">
                      <CircularScore score={result.obtained} label="Obtained Score" color="#6366f1" size={130} />
                      <span className="text-slate-500 text-xs text-center max-w-[100px]">Current CV vs JD match</span>
                    </div>
                    <div className="flex flex-col items-center gap-3">
                      <CircularScore score={result.potential} label="Potential Score" color="#10b981" size={130} />
                      <span className="text-slate-500 text-xs text-center max-w-[100px]">With suggested improvements</span>
                    </div>
                    <div className="flex flex-col items-center gap-3">
                      <CircularScore score={result.negative} label="Negative Grade" color="#ef4444" size={130} />
                      <span className="text-slate-500 text-xs text-center max-w-[100px]">Irrelevant skills in CV</span>
                    </div>
                  </div>
                </div>

                {[
                  {
                    key: 'obtained', title: 'Score Breakdown', icon: Target, color: '#6366f1',
                    content: (
                      <table className="w-full text-sm">
                        <thead><tr className="text-slate-500 text-xs uppercase">
                          <th className="text-left py-2">Criterion</th>
                          <th className="text-right py-2">Score</th>
                          <th className="text-right py-2">Bar</th>
                        </tr></thead>
                        <tbody>{result.breakdown.map(b => (
                          <tr key={b.criterion} className="border-t border-surface-600">
                            <td className="py-2.5 text-slate-400">{b.criterion}</td>
                            <td className="text-right text-white font-semibold">{b.score}/{b.max}</td>
                            <td className="text-right pl-4 w-28">
                              <div className="h-1.5 bg-surface-600 rounded-full overflow-hidden">
                                <div className="h-full rounded-full" style={{ width: `${b.score}%`, background: '#6366f1' }} />
                              </div>
                            </td>
                          </tr>
                        ))}</tbody>
                      </table>
                    )
                  },
                  {
                    key: 'improvements', title: 'Improvement Suggestions', icon: TrendingUp, color: '#10b981',
                    content: (
                      <ul className="space-y-2.5">
                        {result.improvements.map((imp, i) => (
                          <li key={i} className="flex items-start gap-2.5 text-sm text-slate-400">
                            <span className="w-5 h-5 rounded-full bg-accent-500/20 flex items-center justify-center shrink-0 mt-0.5 text-accent-400 text-xs font-bold">{i + 1}</span>
                            {imp}
                          </li>
                        ))}
                      </ul>
                    )
                  },
                  {
                    key: 'negative', title: 'Flagged / Irrelevant Terms', icon: TrendingDown, color: '#ef4444',
                    content: (
                      <table className="w-full text-sm">
                        <thead><tr className="text-slate-500 text-xs uppercase">
                          <th className="text-left py-2">Term</th>
                          <th className="text-right py-2">Severity</th>
                        </tr></thead>
                        <tbody>{result.flaggedTerms.map(f => (
                          <tr key={f.term} className="border-t border-surface-600">
                            <td className="py-2.5 text-slate-300 font-mono text-xs">{f.term}</td>
                            <td className="text-right">
                              <span className={`badge ${f.severity === 'High' ? 'badge-red' : f.severity === 'Medium' ? 'bg-warn-500/10 text-warn-400 border border-warn-500/30' : 'bg-slate-600/20 text-slate-400 border border-slate-600/30'}`}>
                                {f.severity}
                              </span>
                            </td>
                          </tr>
                        ))}</tbody>
                      </table>
                    )
                  },
                ].map(({ key, title, icon: Icon, color, content }) => (
                  <div key={key} className="glass rounded-2xl overflow-hidden">
                    <button onClick={() => setExpandSection(expandSection === key ? null : key)}
                      className="w-full flex items-center justify-between px-6 py-4 text-left">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${color}20` }}>
                          <Icon size={16} style={{ color }} />
                        </div>
                        <span className="font-semibold text-white">{title}</span>
                      </div>
                      {expandSection === key ? <ChevronUp size={18} className="text-slate-500" /> : <ChevronDown size={18} className="text-slate-500" />}
                    </button>
                    <AnimatePresence>
                      {expandSection === key && (
                        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}
                          className="px-6 pb-5 border-t border-surface-700">
                          <div className="pt-4">{content}</div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}

                {/* Company Suggestions (Pro) */}
                <div className="glass rounded-2xl p-6" style={{ borderColor: 'rgba(99,102,241,0.3)' }}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Building2 size={18} className="text-brand-400" />
                      <h3 className="font-semibold text-white">Company Matches</h3>
                    </div>
                    <span className="badge badge-brand">Pro Feature</span>
                  </div>
                  <div className="space-y-3">
                    {result.companies.map(c => (
                      <div key={c.name} className="flex items-center justify-between p-3 rounded-xl"
                        style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                        <div>
                          <p className="font-semibold text-white">{c.name}</p>
                          <div className="flex gap-1 mt-1">{c.skills.map(s => <span key={s} className="badge badge-brand text-[10px] py-0.5">{s}</span>)}</div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-accent-400">{c.match}%</p>
                          <p className="text-slate-600 text-xs">match</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
      <BottomNav />
    </div>
  )
}
