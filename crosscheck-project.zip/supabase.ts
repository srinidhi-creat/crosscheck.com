import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string

// Log Supabase initialization
console.log('🔧 Supabase Init:', {
  url: supabaseUrl ? '✅ Present' : '❌ Missing',
  key: supabaseAnonKey ? '✅ Present' : '❌ Missing',
})

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('❌ CRITICAL: Missing Supabase credentials in .env.local')
  console.error('   VITE_SUPABASE_URL:', supabaseUrl ? 'SET' : 'MISSING')
  console.error('   VITE_SUPABASE_ANON_KEY:', supabaseAnonKey ? 'SET' : 'MISSING')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// ── Type helpers ──────────────────────────────────────────────────────────────
export type UserRole = 'employee' | 'employer'
export type UserTier = 'free' | 'pro'

export interface Profile {
  id: string
  email: string
  name: string | null
  role: UserRole
  tier: UserTier
  verified: boolean
  photo_url: string | null
  created_at: string
}
