import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import SplashScreen from './pages/SplashScreen'
import BrandScreen from './pages/BrandScreen'
import AuthScreen from './pages/AuthScreen'
import TierSelect from './pages/TierSelect'
import PersonalQuestions from './pages/PersonalQuestions'
import EmployeeHome from './pages/EmployeeHome'
import CVAnalysis from './pages/CVAnalysis'
import CommTest from './pages/CommTest'
import Dashboard from './pages/Dashboard'
import EmployerHome from './pages/EmployerHome'
import { supabase } from './lib/supabase'
import { useAuthStore } from './store'

const queryClient = new QueryClient()

// ── Auth listener ─────────────────────────────────────────────────────────────
function AuthListener() {
  const navigate = useNavigate()
  const { setUser, logout } = useAuthStore()

  useEffect(() => {
    // On mount, restore existing session (handles page refresh + OAuth redirect)
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!session?.user) return

      // Ensure profile exists (Google OAuth may have just created the user)
      await supabase.from('profiles').upsert({
        id: session.user.id,
        email: session.user.email!,
        name: session.user.user_metadata?.name ?? session.user.email!.split('@')[0],
        role: session.user.user_metadata?.role ?? 'employee',
      }, { onConflict: 'id', ignoreDuplicates: true })

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .single()

      if (profile) {
        setUser(profile as any)
        // Only auto-navigate if we're on the auth page
        const publicPaths = ['/auth']
        if (publicPaths.includes(window.location.pathname)) {
          navigate(profile.role === 'employer' ? '/employer' : '/home')
        }
      }
    })

    // Live events (sign-in/sign-out during session)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        // Wrap in setTimeout to prevent DB calls from deadlocking GoTrue listener
        setTimeout(async () => {
          // Ensure profile row exists for OAuth sign-ins
          await supabase.from('profiles').upsert({
            id: session.user.id,
            email: session.user.email!,
            name: session.user.user_metadata?.name ?? session.user.email!.split('@')[0],
            role: session.user.user_metadata?.role ?? 'employee',
          }, { onConflict: 'id', ignoreDuplicates: true })

          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single()

          if (profile) {
            setUser(profile as any)
            navigate(profile.role === 'employer' ? '/employer' : '/home')
          }
        }, 0)
      }

      if (event === 'SIGNED_OUT') {
        useAuthStore.getState().clearSession() // Use clearSession instead of logout to prevent recursive Supabase lock
        navigate('/auth')
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  return null
}

// ── Protected route ───────────────────────────────────────────────────────────
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore()
  if (!isAuthenticated) return <Navigate to="/auth" replace />
  return <>{children}</>
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AuthListener />
        <Routes>
          {/* Public */}
          <Route path="/" element={<SplashScreen />} />
          <Route path="/brand" element={<BrandScreen />} />
          <Route path="/auth" element={<AuthScreen />} />

          {/* Employee onboarding */}
          <Route path="/onboarding/tier" element={<ProtectedRoute><TierSelect /></ProtectedRoute>} />
          <Route path="/onboarding/questions" element={<ProtectedRoute><PersonalQuestions /></ProtectedRoute>} />

          {/* Employee app */}
          <Route path="/home" element={<ProtectedRoute><EmployeeHome /></ProtectedRoute>} />
          <Route path="/cv-analysis" element={<ProtectedRoute><CVAnalysis /></ProtectedRoute>} />
          <Route path="/comm-test" element={<ProtectedRoute><CommTest /></ProtectedRoute>} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />

          {/* Employer */}
          <Route path="/employer" element={<ProtectedRoute><EmployerHome /></ProtectedRoute>} />

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}
